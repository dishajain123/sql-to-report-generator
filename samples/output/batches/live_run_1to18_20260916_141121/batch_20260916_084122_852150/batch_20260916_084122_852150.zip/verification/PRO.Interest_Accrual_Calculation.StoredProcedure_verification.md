# Interest Accrual Calculation — Verification & Traceability

> Companion artifact to `PRO.Interest_Accrual_Calculation.StoredProcedure_report.md`. Everything here is pipeline/source provenance for review and audit; none of it appears in the business report.

| Item | Value |
|---|---|
| Object ID | `obj_b44e6db12050` |
| Raw technical object name (from source) | `Interest_Accrual_Calculation` |

## Run Metadata

| Item | Value |
|---|---|
| Pipeline Version | `2026-08-26-phase1` |
| Prompt Version | `3fde9e2078dcda12` |
| Knowledge Base Version | `2e6fc62902751973` |
| Model | `amazon.nova-lite-v1:0` |
| Provider | `bedrock` |
| Dialect | `T-SQL` |
| Dialect Confidence | `High` |
| Source Hash | `1b19d69b88a9d5796a4a078905e8df18bed196202c07fbe535790ca99bf79fd8` |
| Configuration Version | `ddb60c677229031b` |
| Run Timestamp | `2026-09-16T08:52:40.806415+00:00` |
| Object ID | `obj_b44e6db12050` |

## LLM Telemetry

| Item | Value |
|---|---|
| Run ID | `telemetry_efde217ecc81` |
| Total LLM Calls | `5` |
| Successful Calls | `5` |
| Failed Calls | `0` |
| Prompt Tokens | `67909` |
| Completion Tokens | `13250` |
| Total Tokens | `81159` |
| Telemetry Availability | `available` |

| Stage | Calls | Success | Failure | Tokens | Availability |
|---|---:|---:|---:|---:|---|
| extraction | 1 | 1 | 0 | 7228 | available |
| synthesis | 2 | 2 | 0 | 22442 | available |
| synthesis_revision | 2 | 2 | 0 | 51489 | available |

## Business Rule Summary

| Priority | Rule | Output | Business Purpose |
|---|---|---|---|
| 🟠 1 | Determine DaysSinceLastAccrual [MATCHED] (`deterministic_case_0030_0033_1067_dayssincelastaccrual`) | `DaysSinceLastAccrual` | First matching row wins; ELSE includes false or NULL predicates. |
| 🟠 2 | Determine EffectiveInterestRate [MATCHED] (`deterministic_tsql_if_0041_0064_effectiveinterestrate`) | `EffectiveInterestRate` | Not specified |
| 🟠 3 | Determine AccrualTier [MATCHED] (`deterministic_decision_2859_3687_2_accrualtier`) | `AccrualTier` | First matching row wins. SQL type conversion still applies; ELSE includes false or NULL predicates. |
| ⚠️ 4 | Calculate Days Since Last Accrual [MATCHED] (`rule__1__5`) | `DaysSinceLastAccrual` | Determine the number of days since the last accrual for active accounts. |
| ⚠️ 5 | Adjust Effective Interest Rate for Promotional Accounts [MATCHED] (`rule__2__6`) | `EffectiveInterestRate` | Adjust the effective interest rate for promotional accounts opened within the last 90 days. |
| ⚠️ 6 | Insert Accrued Interest Amounts into Staging Table [MATCHED] (`rule__3__7`) | `AccountId, AccruedInterestAmount, AccrualTier` | Insert calculated accrual amounts and tiers into a staging table for active accounts with non-null outstanding balances. |
| ⚠️ 7 | Merge Staging Table Data into Interest Accrual Ledger [LLM_ONLY] (`rule__4__8`) | `AccountId, AccruedInterestAmount, AccrualTier, LastAccrualDate` | Merge the staging table data into the interest accrual ledger, updating existing records or inserting new ones. |
| ⚠️ 8 | Update Outstanding Balance with Accrued Interest [LLM_ONLY] (`rule__5`) | `OutstandingBalance, LastAccrualDate` | Update the outstanding balance of accounts with accrued interest from the staging table. |
| ⚠️ 9 | Insert Review Cases for Large Accruals [CONFLICT] (`rule__6`) | `AccountId, ReviewDate, ShortfallAmount` | Insert review cases for large accrual accounts into the collateral review table. |

## Source Traceability

<details>
<summary><strong>Show rule-to-source mapping</strong></summary>

| # | Rule | Source Evidence | Source Location | SQL Statements / Chunks | Technical References | Notes |
|---|---|---|---|---|---|---|
| 1 | Determine DaysSinceLastAccrual (deterministic_case_0030_0033_1067_dayssincelastaccrual) | Not cited | source \| Lines 30-33 | Not cited | Not cited | Verified |
| 2 | Determine EffectiveInterestRate (deterministic_tsql_if_0041_0064_effectiveinterestrate) | Not cited | source \| Lines 41-64 | Not cited | Not cited | Verified |
| 3 | Determine AccrualTier (deterministic_decision_2859_3687_2_accrualtier) | Not cited | source \| Lines 77-92 | Not cited | Not cited | Verified |
| 4 | Calculate Days Since Last Accrual (rule__1__5) | UPDATE A SET A.DaysSinceLastAccrual = (CASE WHEN A.LastAccrualDate IS NULL THEN 1 ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) END) FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' | Not cited | Not cited | Not cited | Verified |
| 5 | Adjust Effective Interest Rate for Promotional Accounts (rule__2__6) | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate - 0.02 FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND A.PromotionalFlag = 'Y' AND A.AccountOpenDate >= @PromoWindowStart | Not cited | Not cited | Not cited | Verified |
| 6 | Insert Accrued Interest Amounts into Staging Table (rule__3__7) | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLast… | Not cited | Not cited | Not cited | Verified |
| 7 | Merge Staging Table Data into Interest Accrual Ledger (rule__4__8) | MERGE PRO.InterestAccrualLedger AS Target USING #AccrualStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.AccruedInterestAmount = Source.AccruedInterestAmount, Target.AccrualTier = Source.AccrualTier, Target.LastAccr… | Not cited | Not cited | Not cited | Needs Review |
| 8 | Update Outstanding Balance with Accrued Interest (rule__5) | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId | Not cited | Not cited | Not cited | Needs Review |
| 9 | Insert Review Cases for Large Accruals (rule__6) | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' | Not cited | Not cited | Not cited | Needs Review |

### Decision-Chain Branch Provenance

| Branch | Condition | Source Location |
|---|---|---|
| case_0030_0033_1067:branch_001 | A.LastAccrualDate IS NULL | source \| Lines 31-32 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_08 |
| case_0030_0033_1067:branch_002 | ELSE | source \| Lines 32-33 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_08 |
| tsql_if_0041_0064:branch_001 | EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) | source \| Lines 42-56 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_15 |
| tsql_if_0041_0064:branch_002 | ELSE | source \| Lines 58-63 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_17 |
| decision_2859_3687_2:branch_001 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 | source \| Lines 77-92 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_18 |
| decision_2859_3687_2:branch_002 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 | source \| Lines 77-92 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_18 |
| decision_2859_3687_2:branch_003 | ELSE | source \| Lines 77-92 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_18 |
| decision_chain_004:branch_001 | EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) | source |
| decision_chain_004:branch_002 | ELSE | source |
| decision_chain_005:branch_001 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 | source |
| decision_chain_005:branch_002 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 | source |
| decision_chain_005:branch_003 | ELSE | source |

_Source evidence is the literal technical text carried through the pipeline; Source Location is derived deterministically from chunk and statement provenance when available; SQL Statements / Chunks and Technical References point back to the extracted chunk ids and statement references used by the guardrails. Technical references that repeat the same table/operation/target-columns are shown once._
</details>

## Completeness Ledger

- **Executable constructs:** 98
- **Disposition:** covered_by_rule=60, technical_only=4, uncovered=34

| Construct | Status | Source location | Statement / chunk | Evidence |
|---|---|---|---|---|
| STATEMENT | uncovered | Lines 1-1 | 00_batch0_declaration:chunk_text_01, 00_batch0_declaration | USE [DEMO_MISDB] |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:chunk_text_01, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:embedded_01_02, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:chunk_text_01, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:embedded_01_02, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| STATEMENT | uncovered | Lines 1-2 | 03_batch3_main_body+batch3_nested_block:chunk_text_01, 03_batch3_main_body+batch3_nested_block | BEGIN SET NOCOUNT ON |
| STATEMENT | uncovered | Lines 4-4 | 03_batch3_main_body+batch3_nested_block:chunk_text_02, 03_batch3_main_body+batch3_nested_block | BEGIN TRY |
| SELECT | uncovered | Lines 6-6 | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| STATEMENT | uncovered | Lines 7-10 | 03_batch3_main_body+batch3_nested_block:chunk_text_04, 03_batch3_main_body+batch3_nested_block | DECLARE @PromoWindowStart DATE = DATEADD(DAY, -90, @ProcessDate) -- Rule 1: number of days to accrue since the last accrual run; -- accounts never accrued before default to a single day |
| UPDATE | covered_by_rule | Lines 11-23 | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.DaysSinceLastAccrual = ( CASE WHEN A.LastAccrualDate IS NULL THEN 1 ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) END ) FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' -- Rule 2: sequential IF/ELSE - accou... |
| SELECT | uncovered | Lines 24-24 | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | IF EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) |
| STATEMENT | uncovered | Lines 1-1 | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | BEGIN |
| UPDATE | covered_by_rule | Lines 26-31 | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate - 0.02 FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND A.PromotionalFlag = 'Y' AND A.AccountOpenDate >= @PromoWindowStart |
| UPDATE | covered_by_rule | Lines 33-38 | 03_batch3_main_body+batch3_nested_block:chunk_text_09, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND (A.PromotionalFlag = 'N' OR A.PromotionalFlag IS NULL OR A.AccountOpenDate < @PromoWindowStart) |
| STATEMENT | covered_by_rule | Lines 16-16 | 03_batch3_main_body+batch3_nested_block:chunk_text_10, 03_batch3_main_body+batch3_nested_block | END |
| STATEMENT | covered_by_rule | Lines 15-15 | 03_batch3_main_body+batch3_nested_block:chunk_text_11, 03_batch3_main_body+batch3_nested_block | ELSE |
| STATEMENT | uncovered | Lines 1-1 | 03_batch3_main_body+batch3_nested_block:chunk_text_12, 03_batch3_main_body+batch3_nested_block | BEGIN |
| UPDATE | covered_by_rule | Lines 33-36 | 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' |
| STATEMENT | covered_by_rule | Lines 16-16 | 03_batch3_main_body+batch3_nested_block:chunk_text_14, 03_batch3_main_body+batch3_nested_block | END |
| STATEMENT | covered_by_rule | Lines 48-48 | 03_batch3_main_body+batch3_nested_block:chunk_text_15, 03_batch3_main_body+batch3_nested_block | IF OBJECT_ID('tempdb..#AccrualStaging') IS NOT NULL |
| STATEMENT | covered_by_rule | Lines 49-49 | 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block | DROP TABLE #AccrualStaging |
| INSERT | covered_by_rule | Lines 51-59 | 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block | CREATE TABLE #AccrualStaging ( AccountId VARCHAR(20), AccruedInterestAmount DECIMAL(18,2), AccrualTier VARCHAR(10) ) -- Rule 3: conditional INSERT - compute and stage the accrued -- interest only for active accounts with a known balance |
| INSERT | covered_by_rule | Lines 60-74 | 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate /... |
| MERGE | covered_by_rule | Lines 75-88 | 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block | MERGE PRO.InterestAccrualLedger AS Target USING #AccrualStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.AccruedInterestAmount = Source.AccruedInterestAmount, Target.AccrualTier = Source.Accrua... |
| UPDATE | covered_by_rule | Lines 89-96 | 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId -- Rule 6: log a review c... |
| INSERT | covered_by_rule | Lines 97-100 | 03_batch3_main_body+batch3_nested_block:chunk_text_21, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' |
| UPDATE | uncovered | Lines 102-104 | 03_batch3_main_body+batch3_nested_block:chunk_text_22, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| STATEMENT | uncovered | Lines 106-106 | 03_batch3_main_body+batch3_nested_block:chunk_text_23, 03_batch3_main_body+batch3_nested_block | END TRY |
| STATEMENT | uncovered | Lines 107-108 | 03_batch3_main_body+batch3_nested_block:chunk_text_24, 03_batch3_main_body+batch3_nested_block | BEGIN CATCH -- Exception handling: record the failure for operations to investigate |
| UPDATE | uncovered | Lines 109-111 | 03_batch3_main_body+batch3_nested_block:chunk_text_25, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| STATEMENT | uncovered | Lines 112-112 | 03_batch3_main_body+batch3_nested_block:chunk_text_26, 03_batch3_main_body+batch3_nested_block | END CATCH |
| SET | uncovered | Lines 113-113 | 03_batch3_main_body+batch3_nested_block:chunk_text_27, 03_batch3_main_body+batch3_nested_block | SET NOCOUNT OFF |
| STATEMENT | covered_by_rule | Lines 16-16 | 03_batch3_main_body+batch3_nested_block:chunk_text_28, 03_batch3_main_body+batch3_nested_block | END |
| UPDATE | covered_by_rule | Lines 11-23 | 03_batch3_main_body+batch3_nested_block:embedded_01_29, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.DaysSinceLastAccrual = ( CASE WHEN A.LastAccrualDate IS NULL THEN 1 ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) END ) FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' -- Rule 2: sequential IF/ELSE - accou... |
| UPDATE | covered_by_rule | Lines 26-31 | 03_batch3_main_body+batch3_nested_block:embedded_02_30, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate - 0.02 FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND A.PromotionalFlag = 'Y' AND A.AccountOpenDate >= @PromoWindowStart |
| UPDATE | covered_by_rule | Lines 33-38 | 03_batch3_main_body+batch3_nested_block:embedded_03_31, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND (A.PromotionalFlag = 'N' OR A.PromotionalFlag IS NULL OR A.AccountOpenDate < @PromoWindowStart) |
| UPDATE | covered_by_rule | Lines 33-36 | 03_batch3_main_body+batch3_nested_block:embedded_04_32, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' |
| INSERT | covered_by_rule | Lines 60-74 | 03_batch3_main_body+batch3_nested_block:embedded_05_33, 03_batch3_main_body+batch3_nested_block | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate /... |
| MERGE | covered_by_rule | Lines 75-88 | 03_batch3_main_body+batch3_nested_block:embedded_06_34, 03_batch3_main_body+batch3_nested_block | MERGE PRO.InterestAccrualLedger AS Target USING #AccrualStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.AccruedInterestAmount = Source.AccruedInterestAmount, Target.AccrualTier = Source.Accrua... |
| UPDATE | covered_by_rule | Lines 89-96 | 03_batch3_main_body+batch3_nested_block:embedded_07_35, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId -- Rule 6: log a review c... |
| INSERT | covered_by_rule | Lines 97-100 | 03_batch3_main_body+batch3_nested_block:embedded_08_36, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' |
| UPDATE | uncovered | Lines 102-104 | 03_batch3_main_body+batch3_nested_block:embedded_09_37, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| UPDATE | uncovered | Lines 109-111 | 03_batch3_main_body+batch3_nested_block:embedded_10_38, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| SET | uncovered | Lines 113-113 | 03_batch3_main_body+batch3_nested_block:embedded_11_39, 03_batch3_main_body+batch3_nested_block | SET NOCOUNT OFF |
| READ | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| UPDATE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.DaysSinceLastAccrual = ( CASE WHEN A.LastAccrualDate IS NULL THEN 1 ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) END ) FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' -- Rule 2: sequential IF/ELSE - accou... |
| READ | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | IF EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) |
| UPDATE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate - 0.02 FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND A.PromotionalFlag = 'Y' AND A.AccountOpenDate >= @PromoWindowStart |
| UPDATE | uncovered | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_09, 03_batch3_main_body+batch3_nested_block:chunk_text_09, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND (A.PromotionalFlag = 'N' OR A.PromotionalFlag IS NULL OR A.AccountOpenDate < @PromoWindowStart) |
| UPDATE | uncovered | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' |
| INSERT_TEMP | technical_only | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate /... |
| MERGE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block | MERGE PRO.InterestAccrualLedger AS Target USING #AccrualStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.AccruedInterestAmount = Source.AccruedInterestAmount, Target.AccrualTier = Source.Accrua... |
| UPDATE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId -- Rule 6: log a review c... |
| READ_TEMP | technical_only | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId -- Rule 6: log a review c... |
| INSERT | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_21, 03_batch3_main_body+batch3_nested_block:chunk_text_21, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' |
| UPDATE | uncovered | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_22, 03_batch3_main_body+batch3_nested_block:chunk_text_22, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| UPDATE | uncovered | samples/14_Interest_Accrual_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_25, 03_batch3_main_body+batch3_nested_block:chunk_text_25, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_01_29, 03_batch3_main_body+batch3_nested_block:embedded_01_29, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.DaysSinceLastAccrual = ( CASE WHEN A.LastAccrualDate IS NULL THEN 1 ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) END ) FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' -- Rule 2: sequential IF/ELSE - accou... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_02_30, 03_batch3_main_body+batch3_nested_block:embedded_02_30, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate - 0.02 FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND A.PromotionalFlag = 'Y' AND A.AccountOpenDate >= @PromoWindowStart |
| UPDATE | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_03_31, 03_batch3_main_body+batch3_nested_block:embedded_03_31, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' AND (A.PromotionalFlag = 'N' OR A.PromotionalFlag IS NULL OR A.AccountOpenDate < @PromoWindowStart) |
| UPDATE | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_04_32, 03_batch3_main_body+batch3_nested_block:embedded_04_32, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.EffectiveInterestRate = A.BaseInterestRate FROM PRO.LoanAccountCal A WHERE A.AccountStatus = 'ACTIVE' |
| READ | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_05_33, 03_batch3_main_body+batch3_nested_block:embedded_05_33, 03_batch3_main_body+batch3_nested_block | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate /... |
| INSERT_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_05_33, 03_batch3_main_body+batch3_nested_block:embedded_05_33, 03_batch3_main_body+batch3_nested_block | INSERT INTO #AccrualStaging (AccountId, AccruedInterestAmount, AccrualTier) SELECT A.AccountId, (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate /... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_07_35, 03_batch3_main_body+batch3_nested_block:embedded_07_35, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), A.LastAccrualDate = @ProcessDate FROM PRO.LoanAccountCal A INNER JOIN #AccrualStaging S ON S.AccountId = A.AccountId -- Rule 6: log a review c... |
| READ_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_08_36, 03_batch3_main_body+batch3_nested_block:embedded_08_36, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' |
| INSERT | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_08_36, 03_batch3_main_body+batch3_nested_block:embedded_08_36, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.CollateralReview (AccountId, ReviewDate, ShortfallAmount) SELECT AccountId, @ProcessDate, AccruedInterestAmount FROM #AccrualStaging WHERE AccrualTier = 'LARGE' |
| UPDATE | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_09_37, 03_batch3_main_body+batch3_nested_block:embedded_09_37, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| UPDATE | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_10_38, 03_batch3_main_body+batch3_nested_block:embedded_10_38, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Interest_Accrual_Calculation' |
| CASE | covered_by_rule | Lines 31-32 | 03_batch3_main_body+batch3_nested_block:chunk_text_08 | A.LastAccrualDate IS NULL |
| ELSE | covered_by_rule | Lines 32-33 | 03_batch3_main_body+batch3_nested_block:chunk_text_08 | ELSE |
| IF_BRANCH | covered_by_rule | Lines 42-56 | 03_batch3_main_body+batch3_nested_block:chunk_text_15 | EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) |
| ELSE | covered_by_rule | Lines 58-63 | 03_batch3_main_body+batch3_nested_block:chunk_text_17 | ELSE |
| IF_BRANCH | covered_by_rule | Lines 77-92 | 03_batch3_main_body+batch3_nested_block:chunk_text_18 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 |
| IF_BRANCH | covered_by_rule | Lines 77-92 | 03_batch3_main_body+batch3_nested_block:chunk_text_18 | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 |
| ELSE | covered_by_rule | Lines 77-92 | 03_batch3_main_body+batch3_nested_block:chunk_text_18 | ELSE |
| IF_BRANCH | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | full_source | EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = 'Y' AND AccountOpenDate >= @PromoWindowStart) |
| ELSE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | full_source | ELSE |
| IF_BRANCH | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | full_source | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 |
| IF_BRANCH | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | full_source | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 |
| ELSE | covered_by_rule | samples/14_Interest_Accrual_Calculation.sql | full_source | ELSE |
| CASE | covered_by_rule | Lines 30-30 | unavailable | CASE |
| CASE_BRANCH | covered_by_rule | Lines 31-31 | unavailable | WHEN A.LastAccrualDate IS NULL THEN 1 |
| ELSE | covered_by_rule | Lines 32-32 | unavailable | ELSE DATEDIFF(DAY, A.LastAccrualDate, @ProcessDate) |
| IF | covered_by_rule | Lines 41-41 | unavailable | IF EXISTS (SELECT 1 FROM PRO.LoanAccountCal WHERE PromotionalFlag = AND AccountOpenDate >= @PromoWindowStart) |
| ELSE | covered_by_rule | Lines 57-57 | unavailable | ELSE |
| IF | uncovered | Lines 65-65 | unavailable | IF OBJECT_ID( ) IS NOT NULL |
| CALCULATION | covered_by_rule | Lines 79-79 | unavailable | (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual, |
| CASE | covered_by_rule | Lines 80-80 | unavailable | CASE |
| CASE_BRANCH | covered_by_rule | Lines 81-81 | unavailable | WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 THEN |
| CALCULATION | covered_by_rule | Lines 81-81 | unavailable | WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 THEN |
| CASE_BRANCH | covered_by_rule | Lines 82-82 | unavailable | WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 THEN |
| CALCULATION | covered_by_rule | Lines 82-82 | unavailable | WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 THEN |
| ELSE | covered_by_rule | Lines 83-83 | unavailable | ELSE |
| CASE_BRANCH | covered_by_rule | Lines 95-95 | unavailable | WHEN MATCHED THEN |
| CASE_BRANCH | covered_by_rule | Lines 100-100 | unavailable | WHEN NOT MATCHED BY TARGET THEN |
| CALCULATION | covered_by_rule | Lines 107-107 | unavailable | SET A.OutstandingBalance = A.OutstandingBalance + ISNULL(S.AccruedInterestAmount, 0), |
| CATCH | uncovered | Lines 124-124 | unavailable | BEGIN CATCH |
| CATCH | uncovered | Lines 129-129 | unavailable | END CATCH |

## Confirmed Statement Dependencies

The following dependencies are confirmed from exact table/field matches and source order:

| Relationship | From | To | Confidence |
|---|---|---|---|
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_01_29 / PRO.LoanAccountCal | 03_batch3_main_body+batch3_nested_block:chunk_text_06 / PRO.LoanAccountCal | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_01_29 / PRO.LoanAccountCal | 03_batch3_main_body+batch3_nested_block:embedded_05_33 / PRO.LoanAccountCal | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_02_30 / PRO.LoanAccountCal | 03_batch3_main_body+batch3_nested_block:embedded_05_33 / PRO.LoanAccountCal | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_03_31 / PRO.LoanAccountCal | 03_batch3_main_body+batch3_nested_block:embedded_05_33 / PRO.LoanAccountCal | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_04_32 / PRO.LoanAccountCal | 03_batch3_main_body+batch3_nested_block:embedded_05_33 / PRO.LoanAccountCal | high |
| temp_write_to_read | 03_batch3_main_body+batch3_nested_block:embedded_05_33 / #AccrualStaging | 03_batch3_main_body+batch3_nested_block:embedded_08_36 / #AccrualStaging | high |

Unresolved dependency candidates: 48. They were not supplied as confirmed dependencies.

## Rule Provenance Summary

- **Total business rules:** 9
- **By rule type:** deterministic_decision_table = 3, explicit = 6
- **By validation status:** unverified = 3, verified = 6

_This count reflects every individually traceable rule (one per source statement/field, for full auditability). The business report may show a smaller number, because closely related rules that apply the same pattern to several fields (e.g. "reset each of these six DPD fields to zero if negative") are presented there as one combined rule for readability. Every rule counted here is still individually traceable in the Source Traceability table below - none are dropped, only grouped for display._

_Rules marked **unverified** could not be matched back to the technical extraction or source code - this specific claim remains unresolved and should not yet be treated as a confirmed business rule._

## Reconciliation Summary

- **Matched facts:** 18
- **Deterministic-only facts:** 19
- **LLM-only claims:** 2
- **Conflicts:** 6
- **Unresolved items:** 0
- **Review required:** Yes

### Review Items

- `CONFLICT` tables_written (`recon_e662f244045d`): full_source
- `CONFLICT` tables_written (`recon_e662f244045d`): full_source
- `CONFLICT` tables_written (`recon_e662f244045d`): full_source
- `CONFLICT` tables_written (`recon_e662f244045d`): full_source
- `CONFLICT` tables_written (`recon_e662f244045d`): full_source

## Quality Summary

- **Overall status:** REVIEW_REQUIRED
- **Quality score:** 75.11111111111111/100
- **Statement coverage:** 26 / 44 (59.1%)
- **Rule grounding coverage:** 4 / 9 (44.4%)
- **Decision-chain coverage:** 7 / 7 branches (100.0%)
- **Conflicts:** 6
- **Contradictions:** 9
- **Review required items:** 17
- **Review required:** Yes

Statement parse success is below the preferred threshold.; Rule grounding coverage is below the preferred threshold.

### Contradictions

- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.
- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.
- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.

_Quality is derived deterministically from parse success, grounding, conflicts, contradictions, and dialect support._

## Pipeline Diagnostics

- Could not trace the stated source evidence back to a successfully parsed technical extraction record: A.DaysSinceLastAccrual
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: A.EffectiveInterestRate
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: CASE WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 5000 THEN 'LARGE' WHEN (A.OutstandingBalance * A.EffectiveInterestRate / 365) * A.DaysSinceLastAccrual > 1000 THEN 'MEDIUM' ELSE 'SMALL' END
- Synthesized in 2 section(s) aligned to extraction chunk boundaries because the object exceeded the single-call output-token ceiling; sections were merged into this report.
