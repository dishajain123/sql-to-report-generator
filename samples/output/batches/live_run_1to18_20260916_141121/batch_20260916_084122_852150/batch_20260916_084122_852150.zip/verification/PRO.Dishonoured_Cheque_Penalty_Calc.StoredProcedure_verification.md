# Dishonoured Cheque Penalty Calc — Verification & Traceability

> Companion artifact to `PRO.Dishonoured_Cheque_Penalty_Calc.StoredProcedure_report.md`. Everything here is pipeline/source provenance for review and audit; none of it appears in the business report.

| Item | Value |
|---|---|
| Object ID | `obj_4c8f8a44b029` |
| Raw technical object name (from source) | `Dishonoured_Cheque_Penalty_Calc` |

## Run Metadata

| Item | Value |
|---|---|
| Pipeline Version | `2026-08-26-phase1` |
| Prompt Version | `3fde9e2078dcda12` |
| Knowledge Base Version | `2e6fc62902751973` |
| Model | `amazon.nova-lite-v1:0` |
| Provider | `bedrock` |
| Dialect | `T-SQL` |
| Dialect Confidence | `High` |
| Source Hash | `d449240b166222b5c18aaa2aaa825720e537d8fefd960737c15f5a7e2f4da7e2` |
| Configuration Version | `ddb60c677229031b` |
| Run Timestamp | `2026-09-16T08:55:52.576655+00:00` |
| Object ID | `obj_4c8f8a44b029` |

## LLM Telemetry

| Item | Value |
|---|---|
| Run ID | `telemetry_bd3b8986d7a4` |
| Total LLM Calls | `6` |
| Successful Calls | `6` |
| Failed Calls | `0` |
| Prompt Tokens | `70477` |
| Completion Tokens | `15876` |
| Total Tokens | `86353` |
| Telemetry Availability | `available` |

| Stage | Calls | Success | Failure | Tokens | Availability |
|---|---:|---:|---:|---:|---|
| extraction | 1 | 1 | 0 | 7374 | available |
| synthesis | 3 | 3 | 0 | 29859 | available |
| synthesis_revision | 2 | 2 | 0 | 49120 | available |

## Business Rule Summary

| Priority | Rule | Output | Business Purpose |
|---|---|---|---|
| ⚠️ 1 | Update penalty amount [MATCHED] (`rule__1__6`) | `PenaltyAmount` | Assign a penalty amount to dishonoured cheques based on specific conditions. |
| ⚠️ 2 | Mark cheque for review [MATCHED] (`rule__2__7`) | `HoldForReview` | Flag a dishonoured cheque for review if no dishonour reason is provided. |
| ⚠️ 3 | Update account balance [MATCHED] (`rule__3__8`) | `OutstandingBalance` | Adjust the account balance by adding the penalty amount for dishonoured cheques. |
| ⚠️ 4 | Mark penalty as applied [MATCHED] (`rule__4__9`) | `PenaltyApplied` | Indicate that the penalty has been applied to a dishonoured cheque. |
| ⚠️ 5 | Stage penalty data [CONFLICT] (`rule__5__10`) | `#PenaltyStaging.AccountId, #PenaltyStaging.PenaltyAmount, #PenaltyStaging.DishonourCount` | Prepare penalty data for processing by inserting it into a staging table. |
| ⚠️ 6 | Merge penalty data [LLM_ONLY] (`rule__6`) | `PRO.ChequePenaltyLedger.AccountId, PRO.ChequePenaltyLedger.PenaltyAmount, PRO.ChequePenaltyLedger.DishonourCount, PRO.ChequePenaltyLedger.LastPenaltyDate` | Integrate staged penalty data into the cheque penalty ledger. |
| ⚠️ 7 | Identify accounts for suspension [CONFLICT] (`rule__7`) | `#NewSuspensions.AccountId` | Determine which accounts have repeated dishonours and are candidates for cheque book suspension. |
| ⚠️ 8 | Suspend cheque books [CONFLICT] (`rule__8`) | `ChequeBookSuspended, PRO.LoanAccountCal.ChequeBookSuspended` | Suspend the cheque book for accounts identified as having repeated dishonours. |
| ⚠️ 9 | Log account status change [LLM_ONLY] (`rule__9`) | `PRO.AccountStatusAuditLog.AccountId, PRO.AccountStatusAuditLog.TransitionDate, PRO.AccountStatusAuditLog.NewStatus, PRO.AccountStatusAuditLog.Reason` | Record the status change of accounts due to repeated dishonours in the account status audit log. |

## Source Traceability

<details>
<summary><strong>Show rule-to-source mapping</strong></summary>

| # | Rule | Source Evidence | Source Location | SQL Statements / Chunks | Technical References | Notes |
|---|---|---|---|---|---|---|
| 1 | Update penalty amount (rule__1__6) | UPDATE D SET D.PenaltyAmount = (CASE WHEN D.DishonourReason IS NULL THEN NULL WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 WHEN D.RepeatCount = 1 THEN 750.00 ELSE 1500.00 END) FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AN… | Not cited | Not cited | Not cited | Verified |
| 2 | Mark cheque for review (rule__2__7) | UPDATE D SET D.HoldForReview = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.DishonourReason IS NULL | Not cited | Not cited | Not cited | Verified |
| 3 | Update account balance (rule__3__8) | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL | Not cited | Not cited | Not cited | Verified |
| 4 | Mark penalty as applied (rule__4__9) | UPDATE D SET D.PenaltyApplied = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL | Not cited | Not cited | Not cited | Verified |
| 5 | Stage penalty data (rule__5__10) | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FROM PRO.DishonouredChequ… | Not cited | Not cited | Not cited | Needs Review |
| 6 | Merge penalty data (rule__6) | MERGE PRO.ChequePenaltyLedger AS Target USING #PenaltyStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.PenaltyAmount = Target.PenaltyAmount + Source.PenaltyAmount, Target.DishonourCount = Source.DishonourCount, Targ… | Not cited | Not cited | Not cited | Needs Review |
| 7 | Identify accounts for suspension (rule__7) | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) | Not cited | Not cited | Not cited | Needs Review |
| 8 | Suspend cheque books (rule__8) | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) | Not cited | Not cited | Not cited | Needs Review |
| 9 | Log account status change (rule__9) | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions | Not cited | Not cited | Not cited | Needs Review |

### Decision-Chain Branch Provenance

| Branch | Condition | Source Location |
|---|---|---|
| case_0031_0036_1087:branch_001 | D.DishonourReason IS NULL | source \| Lines 32-33 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_06 |
| case_0031_0036_1087:branch_002 | D.RepeatCount IS NULL OR D.RepeatCount = 0 | source \| Lines 33-34 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_06 |
| case_0031_0036_1087:branch_003 | D.RepeatCount = 1 | source \| Lines 34-35 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_07 |
| case_0031_0036_1087:branch_004 | ELSE | source \| Lines 35-36 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_07 |
| tsql_if_0132_0142:branch_001 | EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc') | samples/17_Dishonoured_Cheque_Penalty_Calc.sql \| Lines 133-137 \| Chunk 04_batch3_exception |
| tsql_if_0132_0142:branch_002 | ELSE | samples/17_Dishonoured_Cheque_Penalty_Calc.sql \| Lines 139-142 \| Chunk 04_batch3_exception |
| decision_chain_003:branch_001 | D.DishonourReason IS NULL | source |
| decision_chain_003:branch_002 | D.RepeatCount IS NULL OR D.RepeatCount = 0 | source |
| decision_chain_003:branch_003 | D.RepeatCount = 1 | source |
| decision_chain_003:branch_004 | ELSE | source |

_Source evidence is the literal technical text carried through the pipeline; Source Location is derived deterministically from chunk and statement provenance when available; SQL Statements / Chunks and Technical References point back to the extracted chunk ids and statement references used by the guardrails. Technical references that repeat the same table/operation/target-columns are shown once._
</details>

## Completeness Ledger

- **Executable constructs:** 106
- **Disposition:** covered_by_rule=57, technical_only=8, uncovered=41

| Construct | Status | Source location | Statement / chunk | Evidence |
|---|---|---|---|---|
| STATEMENT | uncovered | Lines 1-1 | 00_batch0_declaration:chunk_text_01, 00_batch0_declaration | USE [DEMO_MISDB] |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:chunk_text_01, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:embedded_01_02, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:chunk_text_01, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:embedded_01_02, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| STATEMENT | uncovered | Lines 1-2 | 03_batch3_main_body+batch3_nested_block:chunk_text_01, 03_batch3_main_body+batch3_nested_block | BEGIN SET NOCOUNT ON |
| STATEMENT | uncovered | Lines 4-4 | 03_batch3_main_body+batch3_nested_block:chunk_text_02, 03_batch3_main_body+batch3_nested_block | BEGIN TRY |
| SELECT | uncovered | Lines 6-6 | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| STATEMENT | uncovered | Lines 7-10 | 03_batch3_main_body+batch3_nested_block:chunk_text_04, 03_batch3_main_body+batch3_nested_block | DECLARE @LookbackWindowStart DATE = DATEADD(MONTH, -6, @ProcessDate) -- Rule 1: multi-branch CASE - penalty scales with how many times -- the account has already been dishonoured |
| UPDATE | covered_by_rule | Lines 11-25 | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyAmount = ( CASE WHEN D.DishonourReason IS NULL THEN NULL WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 WHEN D.RepeatCount = 1 THEN 750.00 ELSE 1500.00 END ) FROM PRO.DishonouredCheque D WHERE D.Dishono... |
| UPDATE | covered_by_rule | Lines 26-33 | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.HoldForReview = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.DishonourReason IS NULL -- Rule 3: apply the computed penalty to the account balance and -- mark the cheque as processed |
| UPDATE | covered_by_rule | Lines 34-39 | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS N... |
| UPDATE | covered_by_rule | Lines 41-45 | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyApplied = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL |
| STATEMENT | uncovered | Lines 47-47 | 03_batch3_main_body+batch3_nested_block:chunk_text_09, 03_batch3_main_body+batch3_nested_block | IF OBJECT_ID('tempdb..#PenaltyStaging') IS NOT NULL |
| STATEMENT | uncovered | Lines 48-48 | 03_batch3_main_body+batch3_nested_block:chunk_text_10, 03_batch3_main_body+batch3_nested_block | DROP TABLE #PenaltyStaging |
| INSERT | uncovered | Lines 50-58 | 03_batch3_main_body+batch3_nested_block:chunk_text_11, 03_batch3_main_body+batch3_nested_block | CREATE TABLE #PenaltyStaging ( AccountId VARCHAR(20), PenaltyAmount DECIMAL(18,2), DishonourCount INT ) -- Rule 4: conditional INSERT - stage only accounts penalised -- today, together with their trailing dishonour count |
| INSERT | covered_by_rule | Lines 59-69 | 03_batch3_main_body+batch3_nested_block:chunk_text_12, 03_batch3_main_body+batch3_nested_block | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FRO... |
| MERGE | covered_by_rule | Lines 70-84 | 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block | MERGE PRO.ChequePenaltyLedger AS Target USING #PenaltyStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.PenaltyAmount = Target.PenaltyAmount + Source.PenaltyAmount, Target.DishonourCount = Sourc... |
| STATEMENT | uncovered | Lines 85-85 | 03_batch3_main_body+batch3_nested_block:chunk_text_14, 03_batch3_main_body+batch3_nested_block | IF OBJECT_ID('tempdb..#NewSuspensions') IS NOT NULL |
| STATEMENT | uncovered | Lines 86-86 | 03_batch3_main_body+batch3_nested_block:chunk_text_15, 03_batch3_main_body+batch3_nested_block | DROP TABLE #NewSuspensions |
| SELECT | covered_by_rule | Lines 88-96 | 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| UPDATE | covered_by_rule | Lines 97-99 | 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| INSERT | covered_by_rule | Lines 101-103 | 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions |
| UPDATE | uncovered | Lines 105-107 | 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| STATEMENT | uncovered | Lines 109-109 | 03_batch3_main_body+batch3_nested_block:chunk_text_20, 03_batch3_main_body+batch3_nested_block | END TRY |
| UPDATE | covered_by_rule | Lines 11-25 | 03_batch3_main_body+batch3_nested_block:embedded_01_21, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyAmount = ( CASE WHEN D.DishonourReason IS NULL THEN NULL WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 WHEN D.RepeatCount = 1 THEN 750.00 ELSE 1500.00 END ) FROM PRO.DishonouredCheque D WHERE D.Dishono... |
| UPDATE | covered_by_rule | Lines 26-33 | 03_batch3_main_body+batch3_nested_block:embedded_02_22, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.HoldForReview = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.DishonourReason IS NULL -- Rule 3: apply the computed penalty to the account balance and -- mark the cheque as processed |
| UPDATE | covered_by_rule | Lines 34-39 | 03_batch3_main_body+batch3_nested_block:embedded_03_23, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS N... |
| UPDATE | covered_by_rule | Lines 41-45 | 03_batch3_main_body+batch3_nested_block:embedded_04_24, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyApplied = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL |
| INSERT | covered_by_rule | Lines 59-69 | 03_batch3_main_body+batch3_nested_block:embedded_05_25, 03_batch3_main_body+batch3_nested_block | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FRO... |
| MERGE | covered_by_rule | Lines 70-84 | 03_batch3_main_body+batch3_nested_block:embedded_06_26, 03_batch3_main_body+batch3_nested_block | MERGE PRO.ChequePenaltyLedger AS Target USING #PenaltyStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.PenaltyAmount = Target.PenaltyAmount + Source.PenaltyAmount, Target.DishonourCount = Sourc... |
| SELECT | covered_by_rule | Lines 88-96 | 03_batch3_main_body+batch3_nested_block:embedded_07_27, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| UPDATE | covered_by_rule | Lines 97-99 | 03_batch3_main_body+batch3_nested_block:embedded_08_28, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| INSERT | covered_by_rule | Lines 101-103 | 03_batch3_main_body+batch3_nested_block:embedded_09_29, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions |
| UPDATE | uncovered | Lines 105-107 | 03_batch3_main_body+batch3_nested_block:embedded_10_30, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| INSERT | uncovered | Lines 1-4 | 04_batch3_exception:chunk_text_01, 04_batch3_exception | BEGIN CATCH -- Exception handling: record the failure for operations to -- investigate, including a fallback insert if the status row -- itself is missing |
| SELECT | uncovered | Lines 5-5 | 04_batch3_exception:chunk_text_02, 04_batch3_exception | IF EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc') |
| STATEMENT | uncovered | Lines 1-1 | 04_batch3_exception:chunk_text_03, 04_batch3_exception | BEGIN |
| UPDATE | uncovered | Lines 7-9 | 04_batch3_exception:chunk_text_04, 04_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| STATEMENT | covered_by_rule | Lines 10-10 | 04_batch3_exception:chunk_text_05, 04_batch3_exception | END |
| STATEMENT | covered_by_rule | Lines 11-11 | 04_batch3_exception:chunk_text_06, 04_batch3_exception | ELSE |
| STATEMENT | uncovered | Lines 1-1 | 04_batch3_exception:chunk_text_07, 04_batch3_exception | BEGIN |
| INSERT | uncovered | Lines 13-14 | 04_batch3_exception:chunk_text_08, 04_batch3_exception | INSERT INTO PRO.ACLRUNNINGPROCESSSTATUS (RUNNINGPROCESSNAME, COMPLETED, ERRORDATE, ERRORDESCRIPTION, COUNT) VALUES ('Dishonoured_Cheque_Penalty_Calc', 'N', GETDATE(), ERROR_MESSAGE(), 1) |
| STATEMENT | covered_by_rule | Lines 10-10 | 04_batch3_exception:chunk_text_09, 04_batch3_exception | END |
| STATEMENT | uncovered | Lines 16-16 | 04_batch3_exception:chunk_text_10, 04_batch3_exception | END CATCH |
| SET | uncovered | Lines 17-17 | 04_batch3_exception:chunk_text_11, 04_batch3_exception | SET NOCOUNT OFF |
| STATEMENT | covered_by_rule | Lines 10-10 | 04_batch3_exception:chunk_text_12, 04_batch3_exception | END |
| UPDATE | uncovered | Lines 7-9 | 04_batch3_exception:embedded_01_13, 04_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| INSERT | uncovered | Lines 13-14 | 04_batch3_exception:embedded_02_14, 04_batch3_exception | INSERT INTO PRO.ACLRUNNINGPROCESSSTATUS (RUNNINGPROCESSNAME, COMPLETED, ERRORDATE, ERRORDESCRIPTION, COUNT) VALUES ('Dishonoured_Cheque_Penalty_Calc', 'N', GETDATE(), ERROR_MESSAGE(), 1) |
| SET | uncovered | Lines 17-17 | 04_batch3_exception:embedded_03_15, 04_batch3_exception | SET NOCOUNT OFF |
| READ | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| UPDATE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyAmount = ( CASE WHEN D.DishonourReason IS NULL THEN NULL WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 WHEN D.RepeatCount = 1 THEN 750.00 ELSE 1500.00 END ) FROM PRO.DishonouredCheque D WHERE D.Dishono... |
| UPDATE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.HoldForReview = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.DishonourReason IS NULL -- Rule 3: apply the computed penalty to the account balance and -- mark the cheque as processed |
| UPDATE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS N... |
| READ | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS N... |
| UPDATE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyApplied = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL |
| INSERT_TEMP | technical_only | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_12, 03_batch3_main_body+batch3_nested_block:chunk_text_12, 03_batch3_main_body+batch3_nested_block | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FRO... |
| MERGE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block:chunk_text_13, 03_batch3_main_body+batch3_nested_block | MERGE PRO.ChequePenaltyLedger AS Target USING #PenaltyStaging AS Source ON Target.AccountId = Source.AccountId WHEN MATCHED THEN UPDATE SET Target.PenaltyAmount = Target.PenaltyAmount + Source.PenaltyAmount, Target.DishonourCount = Sourc... |
| READ_TEMP | technical_only | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| READ | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| INSERT_TEMP | technical_only | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block:chunk_text_16, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| UPDATE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| READ_TEMP | technical_only | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block:chunk_text_17, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| INSERT | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block:chunk_text_18, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions |
| UPDATE | uncovered | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block:chunk_text_19, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_01_21, 03_batch3_main_body+batch3_nested_block:embedded_01_21, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyAmount = ( CASE WHEN D.DishonourReason IS NULL THEN NULL WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 WHEN D.RepeatCount = 1 THEN 750.00 ELSE 1500.00 END ) FROM PRO.DishonouredCheque D WHERE D.Dishono... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_02_22, 03_batch3_main_body+batch3_nested_block:embedded_02_22, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.HoldForReview = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.DishonourReason IS NULL -- Rule 3: apply the computed penalty to the account balance and -- mark the cheque as processed |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_03_23, 03_batch3_main_body+batch3_nested_block:embedded_03_23, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.OutstandingBalance = ISNULL(A.OutstandingBalance, 0) + D.PenaltyAmount FROM PRO.LoanAccountCal A INNER JOIN PRO.DishonouredCheque D ON D.AccountId = A.AccountId WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS N... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_04_24, 03_batch3_main_body+batch3_nested_block:embedded_04_24, 03_batch3_main_body+batch3_nested_block | UPDATE D SET D.PenaltyApplied = 'Y' FROM PRO.DishonouredCheque D WHERE D.DishonourDate = @ProcessDate AND D.PenaltyAmount IS NOT NULL |
| READ | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_05_25, 03_batch3_main_body+batch3_nested_block:embedded_05_25, 03_batch3_main_body+batch3_nested_block | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FRO... |
| INSERT_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_05_25, 03_batch3_main_body+batch3_nested_block:embedded_05_25, 03_batch3_main_body+batch3_nested_block | INSERT INTO #PenaltyStaging (AccountId, PenaltyAmount, DishonourCount) SELECT D.AccountId, D.PenaltyAmount, (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 WHERE D2.AccountId = D.AccountId AND D2.DishonourDate >= @LookbackWindowStart) FRO... |
| READ_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_07_27, 03_batch3_main_body+batch3_nested_block:embedded_07_27, 03_batch3_main_body+batch3_nested_block | SELECT P.AccountId INTO #NewSuspensions FROM #PenaltyStaging P INNER JOIN PRO.LoanAccountCal A ON A.AccountId = P.AccountId WHERE P.DishonourCount >= 3 AND (A.ChequeBookSuspended <> 'Y' OR A.ChequeBookSuspended IS NULL) -- Rule 7: suspen... |
| READ_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_08_28, 03_batch3_main_body+batch3_nested_block:embedded_08_28, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_08_28, 03_batch3_main_body+batch3_nested_block:embedded_08_28, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.LoanAccountCal SET ChequeBookSuspended = 'Y' WHERE AccountId IN (SELECT AccountId FROM #NewSuspensions) |
| READ_TEMP | technical_only | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_09_29, 03_batch3_main_body+batch3_nested_block:embedded_09_29, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions |
| INSERT | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_09_29, 03_batch3_main_body+batch3_nested_block:embedded_09_29, 03_batch3_main_body+batch3_nested_block | INSERT INTO PRO.AccountStatusAuditLog (AccountId, TransitionDate, NewStatus, Reason) SELECT AccountId, @ProcessDate, 'CHEQUE_BOOK_SUSPENDED', 'REPEAT_DISHONOUR_THRESHOLD' FROM #NewSuspensions |
| UPDATE | uncovered | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_10_30, 03_batch3_main_body+batch3_nested_block:embedded_10_30, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| READ | uncovered | unavailable | 04_batch3_exception:chunk_text_02, 04_batch3_exception:chunk_text_02, 04_batch3_exception | IF EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc') |
| UPDATE | uncovered | samples/17_Dishonoured_Cheque_Penalty_Calc.sql / Lines 128-145 | 04_batch3_exception:chunk_text_04, 04_batch3_exception:chunk_text_04, 04_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| INSERT | uncovered | samples/17_Dishonoured_Cheque_Penalty_Calc.sql / Lines 128-145 | 04_batch3_exception:chunk_text_08, 04_batch3_exception:chunk_text_08, 04_batch3_exception | INSERT INTO PRO.ACLRUNNINGPROCESSSTATUS (RUNNINGPROCESSNAME, COMPLETED, ERRORDATE, ERRORDESCRIPTION, COUNT) VALUES ('Dishonoured_Cheque_Penalty_Calc', 'N', GETDATE(), ERROR_MESSAGE(), 1) |
| UPDATE | uncovered | unavailable | 04_batch3_exception:embedded_01_13, 04_batch3_exception:embedded_01_13, 04_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc' |
| CASE | covered_by_rule | Lines 32-33 | 03_batch3_main_body+batch3_nested_block:chunk_text_06 | D.DishonourReason IS NULL |
| CASE | covered_by_rule | Lines 33-34 | 03_batch3_main_body+batch3_nested_block:chunk_text_06 | D.RepeatCount IS NULL OR D.RepeatCount = 0 |
| CASE | covered_by_rule | Lines 34-35 | 03_batch3_main_body+batch3_nested_block:chunk_text_07 | D.RepeatCount = 1 |
| ELSE | covered_by_rule | Lines 35-36 | 03_batch3_main_body+batch3_nested_block:chunk_text_07 | ELSE |
| IF_BRANCH | uncovered | samples/17_Dishonoured_Cheque_Penalty_Calc.sql / Lines 133-137 | 04_batch3_exception | EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc') |
| ELSE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql / Lines 139-142 | 04_batch3_exception | ELSE |
| IF_BRANCH | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | full_source | D.DishonourReason IS NULL |
| IF_BRANCH | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | full_source | D.RepeatCount IS NULL OR D.RepeatCount = 0 |
| IF_BRANCH | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | full_source | D.RepeatCount = 1 |
| ELSE | covered_by_rule | samples/17_Dishonoured_Cheque_Penalty_Calc.sql | full_source | ELSE |
| CASE | covered_by_rule | Lines 31-31 | unavailable | CASE |
| CASE_BRANCH | covered_by_rule | Lines 32-32 | unavailable | WHEN D.DishonourReason IS NULL THEN NULL |
| CASE_BRANCH | covered_by_rule | Lines 33-33 | unavailable | WHEN D.RepeatCount IS NULL OR D.RepeatCount = 0 THEN 350.00 |
| CASE_BRANCH | covered_by_rule | Lines 34-34 | unavailable | WHEN D.RepeatCount = 1 THEN 750.00 |
| ELSE | covered_by_rule | Lines 35-35 | unavailable | ELSE 1500.00 |
| IF | uncovered | Lines 65-65 | unavailable | IF OBJECT_ID( ) IS NOT NULL |
| CALCULATION | covered_by_rule | Lines 79-79 | unavailable | (SELECT COUNT(*) FROM PRO.DishonouredCheque D2 |
| CASE_BRANCH | covered_by_rule | Lines 91-91 | unavailable | WHEN MATCHED THEN |
| CALCULATION | covered_by_rule | Lines 93-93 | unavailable | Target.PenaltyAmount = Target.PenaltyAmount + Source.PenaltyAmount, |
| CASE_BRANCH | covered_by_rule | Lines 96-96 | unavailable | WHEN NOT MATCHED BY TARGET THEN |
| IF | uncovered | Lines 103-103 | unavailable | IF OBJECT_ID( ) IS NOT NULL |
| CATCH | uncovered | Lines 128-128 | unavailable | BEGIN CATCH |
| IF | uncovered | Lines 132-132 | unavailable | IF EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = ) |
| ELSE | covered_by_rule | Lines 138-138 | unavailable | ELSE |
| CATCH | uncovered | Lines 143-143 | unavailable | END CATCH |

## Confirmed Statement Dependencies

The following dependencies are confirmed from exact table/field matches and source order:

| Relationship | From | To | Confidence |
|---|---|---|---|
| table_write_to_later_use | 04_batch3_exception:embedded_01_13 / PRO.ACLRUNNINGPROCESSSTATUS | 04_batch3_exception:chunk_text_08 / PRO.ACLRUNNINGPROCESSSTATUS | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_01_21 / PRO.DishonouredCheque | 03_batch3_main_body+batch3_nested_block:embedded_05_25 / PRO.DishonouredCheque | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_02_22 / PRO.DishonouredCheque | 03_batch3_main_body+batch3_nested_block:embedded_05_25 / PRO.DishonouredCheque | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_04_24 / PRO.DishonouredCheque | 03_batch3_main_body+batch3_nested_block:embedded_05_25 / PRO.DishonouredCheque | high |
| temp_write_to_read | 03_batch3_main_body+batch3_nested_block:embedded_05_25 / #PenaltyStaging | 03_batch3_main_body+batch3_nested_block:embedded_07_27 / #PenaltyStaging | high |
| table_write_to_later_use | 03_batch3_main_body+batch3_nested_block:embedded_10_30 / PRO.ACLRUNNINGPROCESSSTATUS | 04_batch3_exception:chunk_text_08 / PRO.ACLRUNNINGPROCESSSTATUS | high |
| table_write_to_later_use | 04_batch3_exception:chunk_text_04 / PRO.ACLRUNNINGPROCESSSTATUS | 04_batch3_exception:chunk_text_08 / PRO.ACLRUNNINGPROCESSSTATUS | high |

Unresolved dependency candidates: 37. They were not supplied as confirmed dependencies.

## Rule Provenance Summary

- **Total business rules:** 9
- **By rule type:** explicit = 9
- **By validation status:** unverified = 5, verified = 4

_This count reflects every individually traceable rule (one per source statement/field, for full auditability). The business report may show a smaller number, because closely related rules that apply the same pattern to several fields (e.g. "reset each of these six DPD fields to zero if negative") are presented there as one combined rule for readability. Every rule counted here is still individually traceable in the Source Traceability table below - none are dropped, only grouped for display._

_Rules marked **unverified** could not be matched back to the technical extraction or source code - this specific claim remains unresolved and should not yet be treated as a confirmed business rule._

## Reconciliation Summary

- **Matched facts:** 16
- **Deterministic-only facts:** 21
- **LLM-only claims:** 7
- **Conflicts:** 7
- **Unresolved items:** 0
- **Review required:** Yes

### Review Items

- `CONFLICT` tables_read (`recon_a8e91f317680`): full_source
- `CONFLICT` tables_read (`recon_a8e91f317680`): full_source
- `CONFLICT` tables_read (`recon_a8e91f317680`): full_source
- `CONFLICT` tables_written (`recon_1c4a385129d7`): full_source
- `LLM_ONLY` tables_written (`recon_10d523cc95ef`): full_source

## Quality Summary

- **Overall status:** REVIEW_REQUIRED
- **Quality score:** 83.29658730158731/100
- **Statement coverage:** 30 / 50 (60.0%)
- **Rule grounding coverage:** 7 / 9 (77.8%)
- **Decision-chain coverage:** 5 / 6 branches (83.3%)
- **Decision-chain coverage gaps:** 1 branch(es) require review (`EXISTS (SELECT 1 FROM PRO.ACLRUNNINGPROCESSSTATUS WHERE RUNNINGPROCESSNAME = 'Dishonoured_Cheque_Penalty_Calc')`)
- **Conflicts:** 7
- **Contradictions:** 7
- **Review required items:** 21
- **Review required:** Yes

Deterministic decision-chain coverage is incomplete (83.3%).; Statement parse success is below the preferred threshold.

### Contradictions

- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.
- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.
- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `HIGH` Condition Conflict on `source`: Synthesized condition conflicts with deterministic predicate evidence.
- `MEDIUM` Field Conflict on `rule__5__10`: Synthesized rule affects different fields than the deterministic evidence.

_Quality is derived deterministically from parse success, grounding, conflicts, contradictions, and dialect support._

## Pipeline Diagnostics

- Could not trace the stated source evidence back to a successfully parsed technical extraction record: Process status update condition
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: D.PenaltyAmount update condition
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: D.HoldForReview update condition
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: D.PenaltyApplied update condition
- Could not trace the stated source evidence back to a successfully parsed technical extraction record: Staging table insert condition
- Synthesized in 3 section(s) aligned to extraction chunk boundaries because the object exceeded the single-call output-token ceiling; sections were merged into this report.
