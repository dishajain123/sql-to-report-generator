# Provision Percentage Calculation — Verification & Traceability

> Companion artifact to `PRO.Provision_Percentage_Calculation.StoredProcedure_report.md`. Everything here is pipeline/source provenance for review and audit; none of it appears in the business report.

| Item | Value |
|---|---|
| Object ID | `obj_890a2d3ea714` |
| Raw technical object name (from source) | `Provision_Percentage_Calculation` |

## Run Metadata

| Item | Value |
|---|---|
| Pipeline Version | `2026-08-26-phase1` |
| Prompt Version | `3fde9e2078dcda12` |
| Knowledge Base Version | `2e6fc62902751973` |
| Model | `amazon.nova-lite-v1:0` |
| Provider | `bedrock` |
| Dialect | `T-SQL` |
| Dialect Confidence | `High` |
| Source Hash | `a644e9ad7329553f5a95dbe1d6047027e8ac2e37955a3ae74b2c78e3c4029117` |
| Configuration Version | `ddb60c677229031b` |
| Run Timestamp | `2026-09-16T09:18:22.677036+00:00` |
| Object ID | `obj_890a2d3ea714` |

## LLM Telemetry

| Item | Value |
|---|---|
| Run ID | `telemetry_53ca41d39360` |
| Total LLM Calls | `7` |
| Successful Calls | `7` |
| Failed Calls | `0` |
| Prompt Tokens | `52424` |
| Completion Tokens | `10519` |
| Total Tokens | `62943` |
| Telemetry Availability | `available` |

| Stage | Calls | Success | Failure | Tokens | Availability |
|---|---:|---:|---:|---:|---|
| extraction | 1 | 1 | 0 | 4836 | available |
| synthesis | 4 | 4 | 0 | 24331 | available |
| synthesis_revision | 2 | 2 | 0 | 33776 | available |

## Business Rule Summary

| Priority | Rule | Output | Business Purpose |
|---|---|---|---|
| ⚠️ 1 | Increment run count and mark as completed [MATCHED] (`rule__5__11`) | `RunCount, COMPLETED, ErrorDate, ErrorDescription` | Increment the run count for the process and mark it as completed. |
| ⚠️ 2 | Determine provision percentage [MATCHED] (`rule__1__2`) | `ProvisionPct` | Set the provision percentage for accounts based on their asset class. |
| ⚠️ 3 | Increase provision percentage [MATCHED] (`rule__2`) | `ProvisionPct` | Increase the provision percentage by 10% for accounts that are not secured and have a non-standard asset class. |
| ⚠️ 4 | Calculate provision amount [MATCHED] (`rule__3`) | `ProvisionAmount` | Calculate the provision amount for accounts with a positive outstanding balance. |
| ⚠️ 5 | Ensure provision amount does not exceed balance [MATCHED] (`rule__4`) | `ProvisionAmount` | Ensure the provision amount does not exceed the outstanding balance for accounts. |
| ⚠️ 6 | Set senior review flag [MATCHED] (`rule__4__10`) | `SeniorReviewFlag` | Set the senior review flag to 'Y' for accounts with a provision amount over 1 million. |
| ⚠️ 7 | Update run status on error [CONFLICT] (`rule__1__12`) | `COMPLETED, ErrorDate, ErrorDescription, RunCount` | If an exception occurs during the 'Provision_Percentage_Calculation' process, update the run status to indicate the process did not complet… |

## Source Traceability

<details>
<summary><strong>Show rule-to-source mapping</strong></summary>

| # | Rule | Source Evidence | Source Location | SQL Statements / Chunks | Technical References | Notes |
|---|---|---|---|---|---|---|
| 1 | Increment run count and mark as completed (rule__5__11) | UPDATE PRO.RunStatus SET COMPLETED = 'Y', ErrorDate = NULL, ErrorDescription = NULL, RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' | Not cited | 03_batch3_main_body+batch3_nested_block:chunk_text_08 | Not cited | Verified |
| 2 | Determine provision percentage (rule__1__2) | UPDATE A SET A.ProvisionPct = (CASE A.AssetClass WHEN 'STANDARD' THEN 0.40 WHEN 'SUBSTANDARD' THEN 15.00 WHEN 'DOUBTFUL' THEN 25.00 WHEN 'LOSS' THEN 100.00 ELSE 0.00 END) FROM PRO.AccountCal A | Not cited | Not cited | Not cited | Verified |
| 3 | Increase provision percentage (rule__2) | UPDATE A SET A.ProvisionPct = A.ProvisionPct + 10.00 FROM PRO.AccountCal A WHERE A.SecuredFlag = 'N' AND A.AssetClass <> 'STANDARD' | Not cited | Not cited | Not cited | Verified |
| 4 | Calculate provision amount (rule__3) | UPDATE A SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 FROM PRO.AccountCal A WHERE A.OutstandingBalance > 0 | Not cited | Not cited | Not cited | Verified |
| 5 | Ensure provision amount does not exceed balance (rule__4) | UPDATE A SET A.ProvisionAmount = A.OutstandingBalance FROM PRO.AccountCal A WHERE A.ProvisionAmount > A.OutstandingBalance | Not cited | Not cited | Not cited | Verified |
| 6 | Set senior review flag (rule__4__10) | UPDATE A SET A.SeniorReviewFlag = 'Y' FROM PRO.AccountCal A WHERE A.ProvisionAmount > 1000000 | Not cited | Not cited | Not cited | Verified |
| 7 | Update run status on error (rule__1__12) | UPDATE PRO.RunStatus SET COMPLETED = 'N', ErrorDate = GETDATE(), ErrorDescription = ERROR_MESSAGE(), RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' | Not cited | Not cited | source_sql | Needs Review |

### Decision-Chain Branch Provenance

| Branch | Condition | Source Location |
|---|---|---|
| case_0025_0031_748:branch_001 | A.AssetClass = 'STANDARD' | source \| Lines 26-27 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_04 |
| case_0025_0031_748:branch_002 | A.AssetClass = 'SUBSTANDARD' | source \| Lines 27-28 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_04 |
| case_0025_0031_748:branch_003 | A.AssetClass = 'DOUBTFUL' | source \| Lines 28-29 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_04 |
| case_0025_0031_748:branch_004 | A.AssetClass = 'LOSS' | source \| Lines 29-30 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_04 |
| case_0025_0031_748:branch_005 | ELSE | source \| Lines 30-31 \| Statement 03_batch3_main_body+batch3_nested_block:chunk_text_05 |
| decision_chain_002:branch_001 | A.AssetClass = 'STANDARD' | source |
| decision_chain_002:branch_002 | A.AssetClass = 'SUBSTANDARD' | source |
| decision_chain_002:branch_003 | A.AssetClass = 'DOUBTFUL' | source |
| decision_chain_002:branch_004 | A.AssetClass = 'LOSS' | source |
| decision_chain_002:branch_005 | ELSE | source |

_Source evidence is the literal technical text carried through the pipeline; Source Location is derived deterministically from chunk and statement provenance when available; SQL Statements / Chunks and Technical References point back to the extracted chunk ids and statement references used by the guardrails. Technical references that repeat the same table/operation/target-columns are shown once._
</details>

## Completeness Ledger

- **Executable constructs:** 58
- **Disposition:** covered_by_rule=45, uncovered=13

| Construct | Status | Source location | Statement / chunk | Evidence |
|---|---|---|---|---|
| STATEMENT | uncovered | Lines 1-1 | 00_batch0_declaration:chunk_text_01, 00_batch0_declaration | USE [DEMO_MISDB] |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:chunk_text_01, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 01_batch1_declaration:embedded_01_02, 01_batch1_declaration | SET ANSI_NULLS ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:chunk_text_01, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| SET | uncovered | Lines 1-1 | 02_batch2_declaration:embedded_01_02, 02_batch2_declaration | SET QUOTED_IDENTIFIER ON |
| STATEMENT | covered_by_rule | Lines 1-2 | 03_batch3_main_body+batch3_nested_block:chunk_text_01, 03_batch3_main_body+batch3_nested_block | BEGIN SET NOCOUNT ON |
| STATEMENT | covered_by_rule | Lines 4-6 | 03_batch3_main_body+batch3_nested_block:chunk_text_02, 03_batch3_main_body+batch3_nested_block | BEGIN TRY -- Rule 1: base provisioning percentage by asset classification |
| UPDATE | covered_by_rule | Lines 7-19 | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = ( CASE A.AssetClass WHEN 'STANDARD' THEN 0.40 WHEN 'SUBSTANDARD' THEN 15.00 WHEN 'DOUBTFUL' THEN 25.00 WHEN 'LOSS' THEN 100.00 ELSE 0.00 END ) FROM PRO.AccountCal A -- Rule 2: unsecured accounts carry an add... |
| UPDATE | covered_by_rule | Lines 20-28 | 03_batch3_main_body+batch3_nested_block:chunk_text_04, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = A.ProvisionPct + 10.00 FROM PRO.AccountCal A WHERE A.SecuredFlag = 'N' AND A.AssetClass <> 'STANDARD' -- Rule 3 (formula, same shape as the real AddlProvision calculation in -- PRO.UpdateNetBalance_AccountWi... |
| UPDATE | covered_by_rule | Lines 29-34 | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 FROM PRO.AccountCal A WHERE A.OutstandingBalance > 0 -- Rule 4: the provision amount can never exceed the outstanding balance |
| UPDATE | covered_by_rule | Lines 35-40 | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = A.OutstandingBalance FROM PRO.AccountCal A WHERE A.ProvisionAmount > A.OutstandingBalance -- Rule 5: flag large provisions (over 1,000,000) for senior review |
| UPDATE | covered_by_rule | Lines 41-44 | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.SeniorReviewFlag = 'Y' FROM PRO.AccountCal A WHERE A.ProvisionAmount > 1000000 |
| UPDATE | covered_by_rule | Lines 46-48 | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.RunStatus SET COMPLETED = 'Y', ErrorDate = NULL, ErrorDescription = NULL, RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| STATEMENT | covered_by_rule | Lines 50-50 | 03_batch3_main_body+batch3_nested_block:chunk_text_09, 03_batch3_main_body+batch3_nested_block | END TRY |
| UPDATE | covered_by_rule | Lines 7-19 | 03_batch3_main_body+batch3_nested_block:embedded_01_10, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = ( CASE A.AssetClass WHEN 'STANDARD' THEN 0.40 WHEN 'SUBSTANDARD' THEN 15.00 WHEN 'DOUBTFUL' THEN 25.00 WHEN 'LOSS' THEN 100.00 ELSE 0.00 END ) FROM PRO.AccountCal A -- Rule 2: unsecured accounts carry an add... |
| UPDATE | covered_by_rule | Lines 20-28 | 03_batch3_main_body+batch3_nested_block:embedded_02_11, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = A.ProvisionPct + 10.00 FROM PRO.AccountCal A WHERE A.SecuredFlag = 'N' AND A.AssetClass <> 'STANDARD' -- Rule 3 (formula, same shape as the real AddlProvision calculation in -- PRO.UpdateNetBalance_AccountWi... |
| UPDATE | covered_by_rule | Lines 29-34 | 03_batch3_main_body+batch3_nested_block:embedded_03_12, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 FROM PRO.AccountCal A WHERE A.OutstandingBalance > 0 -- Rule 4: the provision amount can never exceed the outstanding balance |
| UPDATE | covered_by_rule | Lines 35-40 | 03_batch3_main_body+batch3_nested_block:embedded_04_13, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = A.OutstandingBalance FROM PRO.AccountCal A WHERE A.ProvisionAmount > A.OutstandingBalance -- Rule 5: flag large provisions (over 1,000,000) for senior review |
| UPDATE | covered_by_rule | Lines 41-44 | 03_batch3_main_body+batch3_nested_block:embedded_05_14, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.SeniorReviewFlag = 'Y' FROM PRO.AccountCal A WHERE A.ProvisionAmount > 1000000 |
| UPDATE | covered_by_rule | Lines 46-48 | 03_batch3_main_body+batch3_nested_block:embedded_06_15, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.RunStatus SET COMPLETED = 'Y', ErrorDate = NULL, ErrorDescription = NULL, RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| STATEMENT | uncovered | Lines 1-2 | 04_batch3_exception:chunk_text_01, 04_batch3_exception | BEGIN CATCH -- Exception handling: record the failure for operations to investigate |
| UPDATE | covered_by_rule | Lines 3-5 | 04_batch3_exception:chunk_text_02, 04_batch3_exception | UPDATE PRO.RunStatus SET COMPLETED = 'N', ErrorDate = GETDATE(), ErrorDescription = ERROR_MESSAGE(), RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| STATEMENT | uncovered | Lines 6-6 | 04_batch3_exception:chunk_text_03, 04_batch3_exception | END CATCH |
| STATEMENT | covered_by_rule | Lines 6-6 | 04_batch3_exception:chunk_text_04, 04_batch3_exception | END |
| UPDATE | covered_by_rule | Lines 3-5 | 04_batch3_exception:embedded_01_05, 04_batch3_exception | UPDATE PRO.RunStatus SET COMPLETED = 'N', ErrorDate = GETDATE(), ErrorDescription = ERROR_MESSAGE(), RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block:chunk_text_03, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = ( CASE A.AssetClass WHEN 'STANDARD' THEN 0.40 WHEN 'SUBSTANDARD' THEN 15.00 WHEN 'DOUBTFUL' THEN 25.00 WHEN 'LOSS' THEN 100.00 ELSE 0.00 END ) FROM PRO.AccountCal A -- Rule 2: unsecured accounts carry an add... |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_04, 03_batch3_main_body+batch3_nested_block:chunk_text_04, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = A.ProvisionPct + 10.00 FROM PRO.AccountCal A WHERE A.SecuredFlag = 'N' AND A.AssetClass <> 'STANDARD' -- Rule 3 (formula, same shape as the real AddlProvision calculation in -- PRO.UpdateNetBalance_AccountWi... |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block:chunk_text_05, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 FROM PRO.AccountCal A WHERE A.OutstandingBalance > 0 -- Rule 4: the provision amount can never exceed the outstanding balance |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block:chunk_text_06, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = A.OutstandingBalance FROM PRO.AccountCal A WHERE A.ProvisionAmount > A.OutstandingBalance -- Rule 5: flag large provisions (over 1,000,000) for senior review |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block:chunk_text_07, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.SeniorReviewFlag = 'Y' FROM PRO.AccountCal A WHERE A.ProvisionAmount > 1000000 |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block:chunk_text_08, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.RunStatus SET COMPLETED = 'Y', ErrorDate = NULL, ErrorDescription = NULL, RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_01_10, 03_batch3_main_body+batch3_nested_block:embedded_01_10, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = ( CASE A.AssetClass WHEN 'STANDARD' THEN 0.40 WHEN 'SUBSTANDARD' THEN 15.00 WHEN 'DOUBTFUL' THEN 25.00 WHEN 'LOSS' THEN 100.00 ELSE 0.00 END ) FROM PRO.AccountCal A -- Rule 2: unsecured accounts carry an add... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_02_11, 03_batch3_main_body+batch3_nested_block:embedded_02_11, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionPct = A.ProvisionPct + 10.00 FROM PRO.AccountCal A WHERE A.SecuredFlag = 'N' AND A.AssetClass <> 'STANDARD' -- Rule 3 (formula, same shape as the real AddlProvision calculation in -- PRO.UpdateNetBalance_AccountWi... |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_03_12, 03_batch3_main_body+batch3_nested_block:embedded_03_12, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 FROM PRO.AccountCal A WHERE A.OutstandingBalance > 0 -- Rule 4: the provision amount can never exceed the outstanding balance |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_04_13, 03_batch3_main_body+batch3_nested_block:embedded_04_13, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.ProvisionAmount = A.OutstandingBalance FROM PRO.AccountCal A WHERE A.ProvisionAmount > A.OutstandingBalance -- Rule 5: flag large provisions (over 1,000,000) for senior review |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_05_14, 03_batch3_main_body+batch3_nested_block:embedded_05_14, 03_batch3_main_body+batch3_nested_block | UPDATE A SET A.SeniorReviewFlag = 'Y' FROM PRO.AccountCal A WHERE A.ProvisionAmount > 1000000 |
| UPDATE | covered_by_rule | unavailable | 03_batch3_main_body+batch3_nested_block:embedded_06_15, 03_batch3_main_body+batch3_nested_block:embedded_06_15, 03_batch3_main_body+batch3_nested_block | UPDATE PRO.RunStatus SET COMPLETED = 'Y', ErrorDate = NULL, ErrorDescription = NULL, RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| UPDATE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql / Lines 67-73 | 04_batch3_exception:chunk_text_02, 04_batch3_exception:chunk_text_02, 04_batch3_exception | UPDATE PRO.RunStatus SET COMPLETED = 'N', ErrorDate = GETDATE(), ErrorDescription = ERROR_MESSAGE(), RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| UPDATE | covered_by_rule | unavailable | 04_batch3_exception:embedded_01_05, 04_batch3_exception:embedded_01_05, 04_batch3_exception | UPDATE PRO.RunStatus SET COMPLETED = 'N', ErrorDate = GETDATE(), ErrorDescription = ERROR_MESSAGE(), RunCount = ISNULL(RunCount, 0) + 1 WHERE ProcessName = 'Provision_Percentage_Calculation' |
| CASE | covered_by_rule | Lines 26-27 | 03_batch3_main_body+batch3_nested_block:chunk_text_04 | A.AssetClass = 'STANDARD' |
| CASE | covered_by_rule | Lines 27-28 | 03_batch3_main_body+batch3_nested_block:chunk_text_04 | A.AssetClass = 'SUBSTANDARD' |
| CASE | covered_by_rule | Lines 28-29 | 03_batch3_main_body+batch3_nested_block:chunk_text_04 | A.AssetClass = 'DOUBTFUL' |
| CASE | covered_by_rule | Lines 29-30 | 03_batch3_main_body+batch3_nested_block:chunk_text_04 | A.AssetClass = 'LOSS' |
| ELSE | covered_by_rule | Lines 30-31 | 03_batch3_main_body+batch3_nested_block:chunk_text_05 | ELSE |
| IF_BRANCH | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | full_source | A.AssetClass = 'STANDARD' |
| IF_BRANCH | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | full_source | A.AssetClass = 'SUBSTANDARD' |
| IF_BRANCH | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | full_source | A.AssetClass = 'DOUBTFUL' |
| IF_BRANCH | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | full_source | A.AssetClass = 'LOSS' |
| ELSE | covered_by_rule | samples/03_Provision_Percentage_Calculation.sql | full_source | ELSE |
| CASE | covered_by_rule | Lines 25-25 | unavailable | CASE A.AssetClass |
| CASE_BRANCH | uncovered | Lines 26-26 | unavailable | WHEN THEN 0.40 |
| CASE_BRANCH | uncovered | Lines 27-27 | unavailable | WHEN THEN 15.00 |
| CASE_BRANCH | uncovered | Lines 28-28 | unavailable | WHEN THEN 25.00 |
| CASE_BRANCH | uncovered | Lines 29-29 | unavailable | WHEN THEN 100.00 |
| ELSE | covered_by_rule | Lines 30-30 | unavailable | ELSE 0.00 |
| CALCULATION | covered_by_rule | Lines 46-46 | unavailable | SET A.ProvisionAmount = (A.OutstandingBalance * A.ProvisionPct) / 100 |
| CATCH | uncovered | Lines 67-67 | unavailable | BEGIN CATCH |
| CATCH | uncovered | Lines 72-72 | unavailable | END CATCH |

## Confirmed Statement Dependencies


Unresolved dependency candidates: 43. They were not supplied as confirmed dependencies.

## Rule Provenance Summary

- **Total business rules:** 7
- **By rule type:** explicit = 7
- **By validation status:** unverified = 1, verified = 6

_This count reflects every individually traceable rule (one per source statement/field, for full auditability). The business report may show a smaller number, because closely related rules that apply the same pattern to several fields (e.g. "reset each of these six DPD fields to zero if negative") are presented there as one combined rule for readability. Every rule counted here is still individually traceable in the Source Traceability table below - none are dropped, only grouped for display._

_Rules marked **unverified** could not be matched back to the technical extraction or source code - this specific claim remains unresolved and should not yet be treated as a confirmed business rule._

## Reconciliation Summary

- **Matched facts:** 9
- **Deterministic-only facts:** 2
- **LLM-only claims:** 0
- **Conflicts:** 2
- **Unresolved items:** 0
- **Review required:** Yes

### Review Items

- `CONFLICT` tables_written (`recon_88a527b0b3ac`): full_source
- `CONFLICT` rule (`recon_77c31f094240`): rule__1__12, 03_batch3_main_body+batch3_nested_block:chunk_text_08;03_batch3_main_body+batch3_nested_block:embedded_06_15;04_batch3_exception:chunk_text_02;04_batch3_exception:embedded_01_05 - Deterministic evidence conflicts with the synthesized claim.
- `DETERMINISTIC_ONLY` coverage (`recon_25f6fb713a68`): 04_batch3_exception, 04_batch3_exception:chunk_text_02 - Deterministic evidence is present in the source but no synthesized rule referenced it.
- `DETERMINISTIC_ONLY` coverage (`recon_25f6fb713a68`): 04_batch3_exception, 04_batch3_exception:embedded_01_05 - Deterministic evidence is present in the source but no synthesized rule referenced it.

## Quality Summary

- **Overall status:** REVIEW_REQUIRED
- **Quality score:** 88.84210526315789/100
- **Statement coverage:** 18 / 25 (72.0%)
- **Rule grounding coverage:** 7 / 7 (100.0%)
- **Decision-chain coverage:** 5 / 5 branches (100.0%)
- **Conflicts:** 2
- **Contradictions:** 3
- **Review required items:** 5
- **Review required:** Yes

Statement parse success is below the preferred threshold.

### Contradictions

- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `MEDIUM` Field Conflict on `rule__1__12`: Synthesized rule affects different fields than the deterministic evidence.
- `HIGH` Rule Vs Rule Conflict on `rule__1__12, rule__5__11`: Rules overlap on the same structured condition but assign different outcomes.

_Quality is derived deterministically from parse success, grounding, conflicts, contradictions, and dialect support._

## Pipeline Diagnostics

- Could not trace the stated source evidence back to a successfully parsed technical extraction record: @TimeKey is provided
- Synthesized in 4 section(s) aligned to extraction chunk boundaries because the object exceeded the single-call output-token ceiling; sections were merged into this report.
