# Batch Job Reconciliation — Verification & Traceability

> Companion artifact to `PRO.Batch_Job_Reconciliation.StoredProcedure_report.md`. Everything here is pipeline/source provenance for review and audit; none of it appears in the business report.

| Item | Value |
|---|---|
| Object ID | `obj_4117700b7512` |
| Raw technical object name (from source) | `Batch_Job_Reconciliation` |

## Run Metadata

| Item | Value |
|---|---|
| Pipeline Version | `2026-08-26-phase1` |
| Prompt Version | `4f519f469b95300a` |
| Knowledge Base Version | `2e6fc62902751973` |
| Model | `amazon.nova-lite-v1:0` |
| Provider | `bedrock` |
| Dialect | `T-SQL` |
| Dialect Confidence | `High` |
| Source Hash | `6b947b845d4b533c7af2a1c8f7c3fbcf08d427b1dd28c8ffbc62d6a4666f4d2e` |
| Configuration Version | `db93bfb59420a471` |
| Run Timestamp | `2026-09-16T23:18:05.358460+00:00` |
| Object ID | `obj_4117700b7512` |

## LLM Telemetry

| Item | Value |
|---|---|
| Run ID | `telemetry_e114a8afca56` |
| Total LLM Calls | `10` |
| Successful Calls | `10` |
| Failed Calls | `0` |
| Prompt Tokens | `96971` |
| Completion Tokens | `9973` |
| Total Tokens | `106944` |
| Telemetry Availability | `available` |

| Stage | Calls | Success | Failure | Tokens | Availability |
|---|---:|---:|---:|---:|---|
| extraction | 1 | 1 | 0 | 7024 | available |
| synthesis | 7 | 7 | 0 | 52669 | available |
| synthesis_revision | 2 | 2 | 0 | 47251 | available |

## Business Rule Summary

| Priority | Rule | Output | Business Purpose |
|---|---|---|---|
| 🟠 1 | Upsert batchreconciliationsummary [MATCHED] (`deterministic_statement_03_batch3_main_body:chunk_text_01:MATCHED_outcome+upsert`) | `Outcome, ShortfallPct, SeverityTier, LastReconciledDate, FeedName, FirstReconciledDate` | Refresh existing rows and insert rows not already present. |
| 🟠 2 | Determine Outcome [MATCHED] (`deterministic_decision_1739_2891_1_outcome`) | `Outcome` | Not specified |
| 🟠 3 | Determine Reason [MATCHED] (`deterministic_decision_5530_5841_2_reason`) | `Reason` | Not specified |
| 🟢 4 | Determine reconciliation outcome [MATCHED] (`rule__1`) | `Outcome` | The outcome of the reconciliation is determined based on the expected and actual row counts, the process date, and the retry count. |
| 🟢 5 | Calculate shortfall percentage [MATCHED] (`rule__2`) | `ShortfallPct` | The shortfall percentage is calculated based on the expected and actual row counts. |
| 🟢 6 | Update RetryCount for retry queued feeds [MATCHED] (`rule__1__11`) | `RetryCount` | Increment the RetryCount for batch feeds that are marked as 'RETRY_QUEUED' in the reconciliation results. |
| 🟢 7 | Determine SeverityTier [MATCHED] (`rule__1__12`) | `SeverityTier` | Set the severity tier of a reconciliation result based on its outcome and shortfall percentage. |
| 🟠 8 | Insert failed reconciliation log [LLM_ONLY] (`rule__2__16`) | `FeedName, Outcome, ReconciledOn` | Log the details of failed reconciliations into the reconciliation log. |
| 🟢 9 | Insert collections queue for failed reconciliations [MATCHED] (`rule__3__17`) | `AccountId, EscalationDate, Reason` | Queue collections for failed reconciliations with the appropriate reason. |

## Source Traceability

<details>
<summary><strong>Show rule-to-source mapping</strong></summary>

| # | Rule | Source Evidence | Source Location | SQL Statements / Chunks | Technical References | Notes |
|---|---|---|---|---|---|---|
| 1 | Upsert batchreconciliationsummary (deterministic_statement_03_batch3_main_body:chunk_text_01:MATCHED_outcome+upsert) | Not cited | source \| Lines 93-108 | 03_batch3_main_body | Not cited | Verified |
| 2 | Determine Outcome (deterministic_decision_1739_2891_1_outcome) | Not cited | source \| Lines 46-70 | Not cited | Not cited | Verified |
| 3 | Determine Reason (deterministic_decision_5530_5841_2_reason) | Not cited | source \| Lines 123-129 | Not cited | Not cited | Verified |
| 4 | Determine reconciliation outcome (rule__1) | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount THEN 'RECONCILED' WHEN @… | Not cited | Not cited | Not cited | Verified |
| 5 | Calculate shortfall percentage (rule__2) | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount THEN 'RECONCILED' WHEN @… | Not cited | Not cited | Not cited | Verified |
| 6 | Update RetryCount for retry queued feeds (rule__1__11) | UPDATE #ReconciliationResults.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') | Not cited | Not cited | Not cited | Verified |
| 7 | Determine SeverityTier (rule__1__12) | WHEN #ReconciliationResults.Outcome = 'RECONCILED' THEN 'NONE'; WHEN #ReconciliationResults.Outcome = 'NOT_APPLICABLE' THEN 'NONE'; WHEN #ReconciliationResults.Outcome = 'RETRY_QUEUED' THEN 'WATCH'; WHEN #ReconciliationResults.Outcome = 'FAILED' AND #Reconcil… | Not cited | Not cited | Not cited | Verified |
| 8 | Insert failed reconciliation log (rule__2__16) | INSERT INTO #ReconciliationResults.BatchReconciliationLog (FeedName, Outcome, ReconciledOn) SELECT #ReconciliationResults.FeedName, #ReconciliationResults.Outcome, #ReconciliationResults.ReconciledOn FROM #ReconciliationResults R | Not cited | Not cited | Not cited | Verified |
| 9 | Insert collections queue for failed reconciliations (rule__3__17) | INSERT INTO #ReconciliationResults.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults WH… | Not cited | Not cited | Not cited | Verified |

### Decision-Chain Branch Provenance

| Branch | Condition | Source Location |
|---|---|---|
| decision_1739_2891_1:branch_001 | ExpectedRowCount IS NULL OR ExpectedRowCount = 0 | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_1:branch_002 | ActualRowCount >= ExpectedRowCount | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_1:branch_003 | @ProcessDate = @MonthEndDate AND (CAST(ExpectedRowCount - ActualRowCount AS NUMERIC(18, 4)) / ExpectedRowCount) * 100 > 10 | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_1:branch_004 | COALESCE(RetryCount, 0) = 0 | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_1:branch_005 | ELSE | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_2:branch_001 | ExpectedRowCount IS NULL OR ExpectedRowCount = 0 | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_2:branch_002 | ActualRowCount >= ExpectedRowCount | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| decision_1739_2891_2:branch_003 | ELSE | samples/18_Batch_Job_Reconciliation.sql \| Lines 46-70 \| Chunk 01_batch3_main_body \| Statement 00_batch3_main_body:chunk_text_09 |
| case_0079_0086_3291:branch_001 | #ReconciliationResults.Outcome = 'RECONCILED' | samples/18_Batch_Job_Reconciliation.sql \| Lines 80-81 \| Chunk 02_batch3_main_body |
| case_0079_0086_3291:branch_002 | #ReconciliationResults.Outcome = 'NOT_APPLICABLE' | samples/18_Batch_Job_Reconciliation.sql \| Lines 81-82 \| Chunk 02_batch3_main_body |
| case_0079_0086_3291:branch_003 | #ReconciliationResults.Outcome = 'RETRY_QUEUED' | samples/18_Batch_Job_Reconciliation.sql \| Lines 82-83 \| Chunk 02_batch3_main_body |
| case_0079_0086_3291:branch_004 | #ReconciliationResults.Outcome = 'FAILED' AND #ReconciliationResults.ShortfallPct > 25 | samples/18_Batch_Job_Reconciliation.sql \| Lines 83-84 \| Chunk 02_batch3_main_body |
| case_0079_0086_3291:branch_005 | #ReconciliationResults.Outcome = 'FAILED' | samples/18_Batch_Job_Reconciliation.sql \| Lines 84-85 \| Chunk 02_batch3_main_body |
| case_0079_0086_3291:branch_006 | ELSE | samples/18_Batch_Job_Reconciliation.sql \| Lines 85-86 \| Chunk 02_batch3_main_body |
| decision_5530_5841_2:branch_001 | SeverityTier = 'CRITICAL' | source \| Lines 123-129 |
| decision_5530_5841_2:branch_002 | ELSE | source \| Lines 123-129 |

_Source evidence is the literal technical text carried through the pipeline; Source Location is derived deterministically from chunk and statement provenance when available; SQL Statements / Chunks and Technical References point back to the extracted chunk ids and statement references used by the guardrails. Technical references that repeat the same table/operation/target-columns are shown once._
</details>

## Completeness Ledger

- **Executable constructs:** 95
- **Disposition:** covered_by_rule=57, technical_only=8, uncovered=30

| Construct | Status | Source location | Statement / chunk | Evidence |
|---|---|---|---|---|
| STATEMENT | uncovered | Lines 1-5 | 00_batch3_main_body:chunk_text_01, 00_batch3_main_body | USE [DEMO_MISDB] SET ANSI_NULLS ON SET QUOTED_IDENTIFIER ON |
| STATEMENT | uncovered | Lines 7-8 | 00_batch3_main_body:chunk_text_02, 00_batch3_main_body | BEGIN SET NOCOUNT ON |
| STATEMENT | uncovered | Lines 11-11 | 00_batch3_main_body:chunk_text_03, 00_batch3_main_body | BEGIN TRY |
| SELECT | uncovered | Lines 15-15 | 00_batch3_main_body:chunk_text_04, 00_batch3_main_body | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| STATEMENT | uncovered | Lines 18-18 | 00_batch3_main_body:chunk_text_05, 00_batch3_main_body | DECLARE @MonthEndDate DATE = EOMONTH(@ProcessDate) |
| STATEMENT | uncovered | Lines 22-22 | 00_batch3_main_body:chunk_text_06, 00_batch3_main_body | IF OBJECT_ID('tempdb..#ReconciliationResults') IS NOT NULL |
| STATEMENT | uncovered | Lines 25-25 | 00_batch3_main_body:chunk_text_07, 00_batch3_main_body | DROP TABLE #ReconciliationResults |
| STATEMENT | uncovered | Lines 29-44 | 00_batch3_main_body:chunk_text_08, 00_batch3_main_body | CREATE TABLE #ReconciliationResults ( FeedName VARCHAR(50), Outcome VARCHAR(20), ShortfallPct DECIMAL(9,4), SeverityTier VARCHAR(10), ReconciledOn DATE ) -- Rule 1: NULL check - a feed with no expected count on record -- cannot be reconc... |
| INSERT | covered_by_rule | Lines 47-70 | 00_batch3_main_body:chunk_text_09, 00_batch3_main_body | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount TH... |
| INSERT | covered_by_rule | Lines 47-70 | 00_batch3_main_body:embedded_01_10, 00_batch3_main_body | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount TH... |
| UPDATE | uncovered | Lines 1-7 | 01_batch3_main_body:chunk_text_01, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| UPDATE | uncovered | Lines 1-7 | 01_batch3_main_body:embedded_01_02, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| UPDATE | uncovered | Lines 1-16 | 02_batch3_main_body:chunk_text_01, 02_batch3_main_body | UPDATE R SET R.SeverityTier = ( CASE WHEN R.Outcome = 'RECONCILED' THEN 'NONE' WHEN R.Outcome = 'NOT_APPLICABLE' THEN 'NONE' WHEN R.Outcome = 'RETRY_QUEUED' THEN 'WATCH' WHEN R.Outcome = 'FAILED' AND R.ShortfallPct > 25 THEN 'CRITICAL' W... |
| UPDATE | uncovered | Lines 1-16 | 02_batch3_main_body:embedded_01_02, 02_batch3_main_body | UPDATE R SET R.SeverityTier = ( CASE WHEN R.Outcome = 'RECONCILED' THEN 'NONE' WHEN R.Outcome = 'NOT_APPLICABLE' THEN 'NONE' WHEN R.Outcome = 'RETRY_QUEUED' THEN 'WATCH' WHEN R.Outcome = 'FAILED' AND R.ShortfallPct > 25 THEN 'CRITICAL' W... |
| MERGE | covered_by_rule | Lines 1-16 | 03_batch3_main_body:chunk_text_01, 03_batch3_main_body | MERGE PRO.BatchReconciliationSummary AS Target USING #ReconciliationResults AS Source ON Target.FeedName = Source.FeedName WHEN MATCHED THEN UPDATE SET Target.Outcome = Source.Outcome, Target.ShortfallPct = Source.ShortfallPct, Target.Se... |
| MERGE | covered_by_rule | Lines 1-16 | 03_batch3_main_body:embedded_01_02, 03_batch3_main_body | MERGE PRO.BatchReconciliationSummary AS Target USING #ReconciliationResults AS Source ON Target.FeedName = Source.FeedName WHEN MATCHED THEN UPDATE SET Target.Outcome = Source.Outcome, Target.ShortfallPct = Source.ShortfallPct, Target.Se... |
| UPDATE | covered_by_rule | Lines 1-8 | 04_batch3_main_body:chunk_text_01, 04_batch3_main_body | UPDATE T SET T.SeverityTier = 'CRITICAL' FROM PRO.BatchReconciliationSummary T WHERE T.Outcome <> 'RECONCILED' AND T.FirstReconciledDate <= DATEADD(DAY, -14, @ProcessDate) -- Rule 6: persist every outcome computed above into the log, --... |
| INSERT | covered_by_rule | Lines 11-16 | 04_batch3_main_body:chunk_text_02, 04_batch3_main_body | INSERT INTO PRO.BatchReconciliationLog (FeedName, Outcome, ReconciledOn) SELECT R.FeedName, R.Outcome, R.ReconciledOn FROM #ReconciliationResults R -- Rule 7: status transition and audit - failed feeds are -- escalated to the collections... |
| INSERT | covered_by_rule | Lines 19-23 | 04_batch3_main_body:chunk_text_03, 04_batch3_main_body | INSERT INTO PRO.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults... |
| UPDATE | covered_by_rule | Lines 27-29 | 04_batch3_main_body:chunk_text_04, 04_batch3_main_body | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| STATEMENT | covered_by_rule | Lines 33-33 | 04_batch3_main_body:chunk_text_05, 04_batch3_main_body | END TRY |
| UPDATE | covered_by_rule | Lines 1-8 | 04_batch3_main_body:embedded_01_06, 04_batch3_main_body | UPDATE T SET T.SeverityTier = 'CRITICAL' FROM PRO.BatchReconciliationSummary T WHERE T.Outcome <> 'RECONCILED' AND T.FirstReconciledDate <= DATEADD(DAY, -14, @ProcessDate) -- Rule 6: persist every outcome computed above into the log, --... |
| INSERT | covered_by_rule | Lines 11-16 | 04_batch3_main_body:embedded_02_07, 04_batch3_main_body | INSERT INTO PRO.BatchReconciliationLog (FeedName, Outcome, ReconciledOn) SELECT R.FeedName, R.Outcome, R.ReconciledOn FROM #ReconciliationResults R -- Rule 7: status transition and audit - failed feeds are -- escalated to the collections... |
| INSERT | covered_by_rule | Lines 19-23 | 04_batch3_main_body:embedded_03_08, 04_batch3_main_body | INSERT INTO PRO.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults... |
| UPDATE | covered_by_rule | Lines 27-29 | 04_batch3_main_body:embedded_04_09, 04_batch3_main_body | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| STATEMENT | uncovered | Lines 1-2 | 05_batch3_exception:chunk_text_01, 05_batch3_exception | BEGIN CATCH -- Exception handling: record the failure for operations to investigate |
| UPDATE | uncovered | Lines 3-5 | 05_batch3_exception:chunk_text_02, 05_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| STATEMENT | uncovered | Lines 6-6 | 05_batch3_exception:chunk_text_03, 05_batch3_exception | END CATCH |
| SET | uncovered | Lines 7-7 | 05_batch3_exception:chunk_text_04, 05_batch3_exception | SET NOCOUNT OFF |
| STATEMENT | covered_by_rule | Lines 6-6 | 05_batch3_exception:chunk_text_05, 05_batch3_exception | END |
| UPDATE | uncovered | Lines 3-5 | 05_batch3_exception:embedded_01_06, 05_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| SET | uncovered | Lines 7-7 | 05_batch3_exception:embedded_02_07, 05_batch3_exception | SET NOCOUNT OFF |
| READ | uncovered | unavailable | 00_batch3_main_body:chunk_text_04, 00_batch3_main_body:chunk_text_04, 00_batch3_main_body | DECLARE @ProcessDate DATE = (SELECT [Date] FROM SysDayMatrix WHERE TimeKey = @TimeKey) |
| INSERT_TEMP | technical_only | samples/18_Batch_Job_Reconciliation.sql | 00_batch3_main_body:chunk_text_09, 00_batch3_main_body:chunk_text_09, 00_batch3_main_body | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount TH... |
| READ | covered_by_rule | unavailable | 00_batch3_main_body:embedded_01_10, 00_batch3_main_body:embedded_01_10, 00_batch3_main_body | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount TH... |
| INSERT_TEMP | technical_only | unavailable | 00_batch3_main_body:embedded_01_10, 00_batch3_main_body:embedded_01_10, 00_batch3_main_body | INSERT INTO #ReconciliationResults (FeedName, Outcome, ShortfallPct, SeverityTier, ReconciledOn) SELECT FeedName, CASE WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN 'NOT_APPLICABLE' WHEN ActualRowCount >= ExpectedRowCount TH... |
| UPDATE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 70-76 | 01_batch3_main_body:chunk_text_01, 01_batch3_main_body:chunk_text_01, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| READ_TEMP | technical_only | samples/18_Batch_Job_Reconciliation.sql / Lines 70-76 | 01_batch3_main_body:chunk_text_01, 01_batch3_main_body:chunk_text_01, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| READ_TEMP | technical_only | unavailable | 01_batch3_main_body:embedded_01_02, 01_batch3_main_body:embedded_01_02, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| UPDATE | uncovered | unavailable | 01_batch3_main_body:embedded_01_02, 01_batch3_main_body:embedded_01_02, 01_batch3_main_body | UPDATE PRO.BatchFeedRegistry SET RetryCount = 1 WHERE FeedDate = @ProcessDate AND FeedName IN (SELECT FeedName FROM #ReconciliationResults WHERE Outcome = 'RETRY_QUEUED') -- Rule 3: multi-branch CASE - derive a severity tier for every --... |
| UPDATE_TEMP | technical_only | samples/18_Batch_Job_Reconciliation.sql / Lines 77-92 | 02_batch3_main_body:chunk_text_01, 02_batch3_main_body:chunk_text_01, 02_batch3_main_body | UPDATE R SET R.SeverityTier = ( CASE WHEN R.Outcome = 'RECONCILED' THEN 'NONE' WHEN R.Outcome = 'NOT_APPLICABLE' THEN 'NONE' WHEN R.Outcome = 'RETRY_QUEUED' THEN 'WATCH' WHEN R.Outcome = 'FAILED' AND R.ShortfallPct > 25 THEN 'CRITICAL' W... |
| UPDATE_TEMP | technical_only | unavailable | 02_batch3_main_body:embedded_01_02, 02_batch3_main_body:embedded_01_02, 02_batch3_main_body | UPDATE R SET R.SeverityTier = ( CASE WHEN R.Outcome = 'RECONCILED' THEN 'NONE' WHEN R.Outcome = 'NOT_APPLICABLE' THEN 'NONE' WHEN R.Outcome = 'RETRY_QUEUED' THEN 'WATCH' WHEN R.Outcome = 'FAILED' AND R.ShortfallPct > 25 THEN 'CRITICAL' W... |
| MERGE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 93-108 | 03_batch3_main_body:chunk_text_01, 03_batch3_main_body:chunk_text_01, 03_batch3_main_body | MERGE PRO.BatchReconciliationSummary AS Target USING #ReconciliationResults AS Source ON Target.FeedName = Source.FeedName WHEN MATCHED THEN UPDATE SET Target.Outcome = Source.Outcome, Target.ShortfallPct = Source.ShortfallPct, Target.Se... |
| UPDATE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql | 04_batch3_main_body:chunk_text_01, 04_batch3_main_body:chunk_text_01, 04_batch3_main_body | UPDATE T SET T.SeverityTier = 'CRITICAL' FROM PRO.BatchReconciliationSummary T WHERE T.Outcome <> 'RECONCILED' AND T.FirstReconciledDate <= DATEADD(DAY, -14, @ProcessDate) -- Rule 6: persist every outcome computed above into the log, --... |
| INSERT | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql | 04_batch3_main_body:chunk_text_02, 04_batch3_main_body:chunk_text_02, 04_batch3_main_body | INSERT INTO PRO.BatchReconciliationLog (FeedName, Outcome, ReconciledOn) SELECT R.FeedName, R.Outcome, R.ReconciledOn FROM #ReconciliationResults R -- Rule 7: status transition and audit - failed feeds are -- escalated to the collections... |
| INSERT | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql | 04_batch3_main_body:chunk_text_03, 04_batch3_main_body:chunk_text_03, 04_batch3_main_body | INSERT INTO PRO.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults... |
| UPDATE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql | 04_batch3_main_body:chunk_text_04, 04_batch3_main_body:chunk_text_04, 04_batch3_main_body | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| UPDATE | covered_by_rule | unavailable | 04_batch3_main_body:embedded_01_06, 04_batch3_main_body:embedded_01_06, 04_batch3_main_body | UPDATE T SET T.SeverityTier = 'CRITICAL' FROM PRO.BatchReconciliationSummary T WHERE T.Outcome <> 'RECONCILED' AND T.FirstReconciledDate <= DATEADD(DAY, -14, @ProcessDate) -- Rule 6: persist every outcome computed above into the log, --... |
| READ_TEMP | technical_only | unavailable | 04_batch3_main_body:embedded_02_07, 04_batch3_main_body:embedded_02_07, 04_batch3_main_body | INSERT INTO PRO.BatchReconciliationLog (FeedName, Outcome, ReconciledOn) SELECT R.FeedName, R.Outcome, R.ReconciledOn FROM #ReconciliationResults R -- Rule 7: status transition and audit - failed feeds are -- escalated to the collections... |
| READ_TEMP | technical_only | unavailable | 04_batch3_main_body:embedded_03_08, 04_batch3_main_body:embedded_03_08, 04_batch3_main_body | INSERT INTO PRO.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults... |
| INSERT | covered_by_rule | unavailable | 04_batch3_main_body:embedded_03_08, 04_batch3_main_body:embedded_03_08, 04_batch3_main_body | INSERT INTO PRO.CollectionsQueue (AccountId, EscalationDate, Reason) SELECT FeedName, ReconciledOn, CASE WHEN SeverityTier = 'CRITICAL' THEN 'FEED_RECONCILIATION_CRITICAL' ELSE 'FEED_RECONCILIATION_FAILED' END FROM #ReconciliationResults... |
| UPDATE | covered_by_rule | unavailable | 04_batch3_main_body:embedded_04_09, 04_batch3_main_body:embedded_04_09, 04_batch3_main_body | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'Y', ERRORDATE = NULL, ERRORDESCRIPTION = NULL, COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| UPDATE | uncovered | samples/18_Batch_Job_Reconciliation.sql / Lines 134-141 | 05_batch3_exception:chunk_text_02, 05_batch3_exception:chunk_text_02, 05_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| UPDATE | uncovered | unavailable | 05_batch3_exception:embedded_01_06, 05_batch3_exception:embedded_01_06, 05_batch3_exception | UPDATE PRO.ACLRUNNINGPROCESSSTATUS SET COMPLETED = 'N', ERRORDATE = GETDATE(), ERRORDESCRIPTION = ERROR_MESSAGE(), COUNT = ISNULL(COUNT, 0) + 1 WHERE RUNNINGPROCESSNAME = 'Batch_Job_Reconciliation' |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ExpectedRowCount IS NULL OR ExpectedRowCount = 0 |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ActualRowCount >= ExpectedRowCount |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | @ProcessDate = @MonthEndDate AND (CAST(ExpectedRowCount - ActualRowCount AS NUMERIC(18, 4)) / ExpectedRowCount) * 100 > 10 |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | COALESCE(RetryCount, 0) = 0 |
| ELSE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ELSE |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ExpectedRowCount IS NULL OR ExpectedRowCount = 0 |
| IF_BRANCH | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ActualRowCount >= ExpectedRowCount |
| ELSE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 46-70 | 00_batch3_main_body:chunk_text_09, 01_batch3_main_body | ELSE |
| CASE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 80-81 | 02_batch3_main_body | #ReconciliationResults.Outcome = 'RECONCILED' |
| CASE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 81-82 | 02_batch3_main_body | #ReconciliationResults.Outcome = 'NOT_APPLICABLE' |
| CASE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 82-83 | 02_batch3_main_body | #ReconciliationResults.Outcome = 'RETRY_QUEUED' |
| CASE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 83-84 | 02_batch3_main_body | #ReconciliationResults.Outcome = 'FAILED' AND #ReconciliationResults.ShortfallPct > 25 |
| CASE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 84-85 | 02_batch3_main_body | #ReconciliationResults.Outcome = 'FAILED' |
| ELSE | covered_by_rule | samples/18_Batch_Job_Reconciliation.sql / Lines 85-86 | 02_batch3_main_body | ELSE |
| IF_BRANCH | covered_by_rule | Lines 123-129 | unavailable | SeverityTier = 'CRITICAL' |
| ELSE | covered_by_rule | Lines 123-129 | unavailable | ELSE |
| IF | uncovered | Lines 27-27 | unavailable | IF OBJECT_ID( ) IS NOT NULL |
| CASE | covered_by_rule | Lines 49-49 | unavailable | CASE |
| CASE_BRANCH | covered_by_rule | Lines 50-50 | unavailable | WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN |
| CASE_BRANCH | covered_by_rule | Lines 51-51 | unavailable | WHEN ActualRowCount >= ExpectedRowCount THEN |
| CASE_BRANCH | covered_by_rule | Lines 52-52 | unavailable | WHEN @ProcessDate = @MonthEndDate |
| CASE_BRANCH | covered_by_rule | Lines 55-55 | unavailable | WHEN ISNULL(RetryCount, 0) = 0 THEN |
| ELSE | covered_by_rule | Lines 56-56 | unavailable | ELSE |
| CASE | covered_by_rule | Lines 58-58 | unavailable | CASE |
| CASE_BRANCH | covered_by_rule | Lines 59-59 | unavailable | WHEN ExpectedRowCount IS NULL OR ExpectedRowCount = 0 THEN NULL |
| CASE_BRANCH | covered_by_rule | Lines 60-60 | unavailable | WHEN ActualRowCount >= ExpectedRowCount THEN 0 |
| ELSE | covered_by_rule | Lines 61-61 | unavailable | ELSE (CAST(ExpectedRowCount - ActualRowCount AS DECIMAL(18,4)) / ExpectedRowCount) * 100 |
| CASE | covered_by_rule | Lines 79-79 | unavailable | CASE |
| CASE_BRANCH | uncovered | Lines 80-80 | unavailable | WHEN R.Outcome = THEN |
| CASE_BRANCH | uncovered | Lines 81-81 | unavailable | WHEN R.Outcome = THEN |
| CASE_BRANCH | uncovered | Lines 82-82 | unavailable | WHEN R.Outcome = THEN |
| CASE_BRANCH | uncovered | Lines 83-83 | unavailable | WHEN R.Outcome = AND R.ShortfallPct > 25 THEN |
| CASE_BRANCH | uncovered | Lines 84-84 | unavailable | WHEN R.Outcome = THEN |
| ELSE | covered_by_rule | Lines 85-85 | unavailable | ELSE |
| CASE_BRANCH | covered_by_rule | Lines 96-96 | unavailable | WHEN MATCHED THEN |
| CASE_BRANCH | covered_by_rule | Lines 102-102 | unavailable | WHEN NOT MATCHED BY TARGET THEN |
| CASE | covered_by_rule | Lines 125-125 | unavailable | CASE WHEN SeverityTier = THEN ELSE END |
| CASE_BRANCH | covered_by_rule | Lines 125-125 | unavailable | CASE WHEN SeverityTier = THEN ELSE END |
| ELSE | covered_by_rule | Lines 125-125 | unavailable | CASE WHEN SeverityTier = THEN ELSE END |
| CATCH | uncovered | Lines 134-134 | unavailable | BEGIN CATCH |
| CATCH | uncovered | Lines 139-139 | unavailable | END CATCH |

## Confirmed Statement Dependencies

The following dependencies are confirmed from exact table/field matches and source order:

| Relationship | From | To | Confidence |
|---|---|---|---|
| table_write_to_later_use | 01_batch3_main_body:embedded_01_02 / PRO.BatchFeedRegistry | 00_batch3_main_body:embedded_01_10 / PRO.BatchFeedRegistry | high |
| temp_write_to_read | 02_batch3_main_body:embedded_01_02 / #ReconciliationResults | 04_batch3_main_body:embedded_02_07 / #ReconciliationResults | high |
| temp_write_to_read | 02_batch3_main_body:embedded_01_02 / #ReconciliationResults | 04_batch3_main_body:embedded_03_08 / #ReconciliationResults | high |
| table_write_to_later_use | 02_batch3_main_body:embedded_01_02 / #ReconciliationResults | 00_batch3_main_body:embedded_01_10 / #ReconciliationResults | high |
| temp_write_to_read | 02_batch3_main_body:embedded_01_02 / #ReconciliationResults | 01_batch3_main_body:chunk_text_01 / #ReconciliationResults | high |
| later_update_overrides_field | 02_batch3_main_body:embedded_01_02 / #ReconciliationResults | 02_batch3_main_body:chunk_text_01 / #ReconciliationResults | high |
| staging_write_to_merge | 04_batch3_main_body:embedded_01_06 / PRO.BatchReconciliationSummary | 03_batch3_main_body:chunk_text_01 / PRO.BatchReconciliationSummary | high |
| temp_write_to_read | 00_batch3_main_body:embedded_01_10 / #ReconciliationResults | 01_batch3_main_body:chunk_text_01 / #ReconciliationResults | high |
| table_write_to_later_use | 00_batch3_main_body:embedded_01_10 / #ReconciliationResults | 02_batch3_main_body:chunk_text_01 / #ReconciliationResults | high |

Unresolved dependency candidates: 13. They were not supplied as confirmed dependencies.

## Rule Provenance Summary

- **Total business rules:** 9
- **By rule type:** deterministic_decision_table = 3, explicit = 6
- **By validation status:** verified = 9

_This count reflects every individually traceable rule (one per source statement/field, for full auditability). The business report may show a smaller number, because closely related rules that apply the same pattern to several fields (e.g. "reset each of these six DPD fields to zero if negative") are presented there as one combined rule for readability. Every rule counted here is still individually traceable in the Source Traceability table below - none are dropped, only grouped for display._

## Reconciliation Summary

- **Matched facts:** 17
- **Deterministic-only facts:** 14
- **LLM-only claims:** 6
- **Conflicts:** 3
- **Unresolved items:** 0
- **Review required:** Yes

### Review Items

- `LLM_ONLY` tables_read (`recon_f75276f4e2d1`): full_source
- `LLM_ONLY` tables_read (`recon_f75276f4e2d1`): full_source
- `CONFLICT` tables_written (`recon_824c82d25092`): full_source
- `LLM_ONLY` tables_written (`recon_dc5de928af01`): full_source
- `CONFLICT` tables_written (`recon_824c82d25092`): full_source

## Quality Summary

- **Overall status:** REVIEW_REQUIRED
- **Quality score:** 77.70816326530611/100
- **Statement coverage:** 20 / 32 (62.5%)
- **Rule grounding coverage:** 6 / 10 (60.0%)
- **Decision-chain coverage:** 16 / 16 branches (100.0%)
- **Conflicts:** 3
- **Contradictions:** 4
- **Review required items:** 13
- **Review required:** Yes

Statement parse success is below the preferred threshold.; Rule grounding coverage is below the preferred threshold.

### Contradictions

- `HIGH` Operation Conflict on `source`: Synthesized table operation conflicts with deterministic SQL/AST evidence.
- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `MEDIUM` Field Conflict on `source`: Synthesized affected fields do not match deterministic SQL/AST evidence.
- `MEDIUM` Field Conflict on `rule__1__13+upsert`: Synthesized rule affects different fields than the deterministic evidence.

_Quality is derived deterministically from parse success, grounding, conflicts, contradictions, and dialect support._

## Pipeline Diagnostics

- Synthesized in 7 section(s) aligned to extraction chunk boundaries because the object exceeded the single-call output-token ceiling; sections were merged into this report.
